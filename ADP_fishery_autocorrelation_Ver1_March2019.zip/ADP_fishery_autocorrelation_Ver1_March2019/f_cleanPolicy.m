function pFunOut = f_cleanPolicy(pFunin,x_node,Gf,nN1,nK,nR,np,nc)    

pFunOut = reshape(pFunin,[nN1,nK,nR,np,nc]);  %convert to array

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if 1
    disp('Policy cleaning turned off')
    return
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pFunOut4Comp = pFunOut;

NextNis0 = Gf(x_node(:,2),x_node(:,3),x_node(:,1))==0; %cases in which next N is zero (either because N=0 or N is too high).
pFunOut(NextNis0) = 1; % Ensure that when NextN=0, escapement set to 1.  Doesn't matter directly but makes for a more consistent escapement function shape to facilitate good interpolation.   

%Loop through all shock level quadruplets and ensure shape of escapement
%function is regular.  At low N, sometimes the line of escapement=1 is
%broken by errant departures from 1.  But smoothing algorithm needs to
%acknowledge that there are legitimate 1's at high N as well.  
for j1=1:nK; for j2=1:nR; for j3=1:np; for j4=1:nc
    %j1 =1; j2=1; j3=1; j4=1;
    pfN = pFunOut(:,j1,j2,j3,j4); 
    last1 = find(pfN>=1-eps,1,'last');   
    if ~isempty(last1)  %if there's at least 1 value of 1.
        while last1 == length(pfN)  %Temporarily trim 1's off end of optimal escapement vector (sometimes appear at high N) to allow exam of only low N A=1 space
            %viz:
            %figure(92); plot(x_node(1:nN1,1),pfN,'.-')
            pfN(end) = []; 
            last1 = find(pfN>=1-eps,1,'last'); 
        end
        pFunOut(1:last1,j1,j2,j3,j4)=1;
        %Look at cases where a correction is made
        if 0 && ~isequal(pFunOut(:,j1,j2,j3,j4),pFunOut4Comp(:,j1,j2,j3,j4))
            figure(92); plot(x_node(1:nN1,1),[pFunOut(:,j1,j2,j3,j4), pFunOut4Comp(:,j1,j2,j3,j4)],'.-')
            title(num2str([j1,j2,j3,j4]))
            temp=12;
        end
    end
end; end; end; end   

pFChg = find(pFunOut4Comp~=pFunOut); %pFun changed
disp(['Policy corrections made in ' num2str(length(pFChg)/(nN1*nK*nR*np*nc)) ' share of cases'])

%[pFunOut4Comp(pFChg) pFunOut(pFChg)]