function [pi_a, nextstates_a] = f_nextperiod_multshock_sf(z,states,A,xMinMax,G_popdyn,PI_netprof)
% pi_a is a column vector of each profit that would result from each of a vector of actions.
% states: state levels at beginning of period
% z: new updated shock state levels

% Ordering of shocks in vector z: [K R-or-K0 price cost]  
zK = z(1); zR = z(2); zp = z(3); zc = z(4);

% Pop dynamics: growth+shock then harvest 
n_preharv    = G_popdyn(zK,zR,states(1));       % growth with shocks to carrying capacity (zK=z(1)) and growth rate (zR=z(2))
nextstates_a = min(xMinMax(2,1),n_preharv*A);   % escapement is applied. 

% Profit: calculate profit with two shocks:
pi_a = PI_netprof(zp,zc,n_preharv,A); 

% Check profit:
if 0 % Turn off for simulations.
    if sum(~isfinite(pi_a))>0;  error('Elements of profit are not finite (inf, NaN, etc.)'); end
    if max(pi_a) <0;            error('Profit is negative, pi<0');  end  
end

if sum(nextstates_a<0)>0  %some actions lead to negative stock
    nextstates_a(nextstates_a<0) = 0;
end

% Check nextstates_a:
if sum(~isfinite(nextstates_a(:)))>0; error('Elements of nexstates_a are not finite (inf, NaN, etc.'); end
if ~all(nextstates_a(:,1)>=xMinMax(1,1) & nextstates_a(:,1)<=xMinMax(2,1))
    error(['f_nextperiod_multshock_sf: Stock level is outside of range: ' num2str([min(nextstates_a(:,1))])]); % max(nextstates_a(:,1))])]); 
end          %Make sure x_a is within ranges

end

%figure(12); ezplot(@(x) G_popdyn(zK,zR,x),[0,200])