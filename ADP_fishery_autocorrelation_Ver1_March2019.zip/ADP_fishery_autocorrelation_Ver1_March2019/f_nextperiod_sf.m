function [pi_a, nextstates_a] = f_nextperiod_sf(z,N,A,xMinMax,G_popdyn,PI_netprof)
% pi_a is a column vector of each profit that would result from each of a vector of actions.

% Profit
pi_a = PI_netprof(z,N,A);

% Check profit:
if sum(~isfinite(pi_a))>0;  error('Elements of profit are not finite (inf, NaN, etc.)'); end
if max(pi_a) <0;            error('Profit is negative, pi<0');  end  

% Dynamics: Next period stock given: current stock, shock, harvest, growth 
% Order of operations: obs N, shock o, choose A, growth.
nextstates_a    = G_popdyn(z*N*A);

% Ensure no negative stock levels
if sum(nextstates_a<0)>0  %some actions lead to negative stock
    nextstates_a(nextstates_a<0) = 0;
end

% Check nextstates_a:
if sum(~isfinite(nextstates_a(:)))>0; error('Elements of nexstates_a are not finite (inf, NaN, etc.'); end
if ~all(nextstates_a(:,1)>=xMinMax(1,1) & nextstates_a(:,1)<=xMinMax(2,1)); 
    error(['Stock level is outside of range: ' num2str([min(nextstates_a(:,1)) max(nextstates_a(:,1))])]); 
end  %Make sure x_a is within ranges


end 
