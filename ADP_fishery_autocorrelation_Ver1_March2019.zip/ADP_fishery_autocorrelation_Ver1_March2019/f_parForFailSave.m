%% Save output during parfor fail to debug
function f_parForFailSave(reason,V_a,Vtilde,n_sim_blk,Gf,z,systmodel,sol_meth,multTCorrShk,pi_a,delta,Vn_a,nextstates_a,states)
    save('parForFailSave.mat');
end