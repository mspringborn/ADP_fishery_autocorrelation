function  Vout_a = f_predict_w0(mdl,x_a,xstd,xmean,Vstd,Vmean,N1v,fi_predict_cs,rshp,x_node,Vbar)

% %%%%%%%%%%%%%%%%TEMP fix for high x_a
% x_a(:,1) = min(x_a(:,1),N1v(end)); 


Vout_a = -inf*ones(size(x_a,1),1); %initialize to -inf.  if not replaced will be obvious.
% inc0 = 1; 
% if inc0 == 0
%     %if not all stocks considered are above lowest nonzero stock node, need to interpolate.
%     trp = x_a(:,1)<N1v(2); %rows to interpolate, value given by interpolation instead of mdl
%     if sum(~trp)>0  %if at least some rows above 2nd stock node, calculate with mdl
%         Vout_a(~trp) = max(0,f_predict_cs(mdl,x_a(~trp,:),xstd,xmean,Vstd,Vmean));
%     end
%     if sum(trp)>0 
%         Vout_a(trp)  = interpn(rshp(x_node(:,1)),rshp(Vbar),...
%                                     x_a(trp,1), 'spline');  %Spline will extrapolate for values outside range--only occurs for mu which may be slightly higher than range in state vector. 
%         if ~all(diff(Vout_a(trp))>0) ||  ~all(Vout_a(trp)>0)  % if not positive or not monotonic do linear instead
%             Vout_a(trp)  = interpn(rshp(x_node(:,1)),rshp(Vbar),...
%                                         x_a(trp,1),'linear'); 
%         end
%     end
% elseif inc0==1
    Vout_a = max(0,fi_predict_cs(mdl,x_a,xstd,xmean,Vstd,Vmean));
% end

return