% main  
% solve for value function in a fisheries model using either 
    %1. value function iteration ("VFI"), or 
    %2. forward approximate dynamic programing ("FDP")
% Version 1.0 
% Copyright (C) 2019  Michael Springborn
% This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
% This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
% % You should have received a copy of the GNU General Public License along with this program.  If not, see <https://www.gnu.org/licenses/>.

%% Preamble/setup
clear
dbstop if error

% Specify output directories
saveloc         = 'output\';                        % Save mat-file output
working_figloc  = ['\' saveloc 'working_figs\'];    % Working figs (debugging, etc.)
cdall           = cd;
% Set figure location: replace with prefered location--construction is unique to user.  
figloc          = [cdall(1:end-4) 'Writing\figs\'];  %Figs for presentation/paper  

doparfor = true;  % Use parallel computing (parfor).  
%doparfor = false; % Also need to manually comment out parfor call in sc_FDP_parallel if switching to for-loop.
display(['You are running with doparfor set to: ' num2str(doparfor)])


%% Specify biologial growth and uncertainties models 
% Biological growth model, e.g. simple base model, model with critical depensation, etc.
if     1;   systmodel = 'base';     %base model -- logistic growth
elseif 0;   systmodel = 'critdep';  %critical depensation model
elseif 0;   systmodel = 'rick';     %Ricker
end

% Focal uncertainty model: 
if 1; multTCorrShk = false; % Single shock   
else  multTCorrShk = true;  % Extends model from single shock to multiple shocks, correlated over time
end

%% Specify solution approach
if 0; sol_meth = 'VFI';  
else  sol_meth = 'FDP';
end

% Specify version number and casename to track results:
if 1 % main case
    ver = '1'; 
else % specify sensitivity analysis case 1:4 
    snstvty=4;
    if     snstvty==1; ver = 'Kp10';  elseif snstvty==2; ver = 'Km10'; elseif snstvty==3; ver = 'Cp10';  elseif snstvty==4; ver = 'Cm10'; 
    end
end

casename = [sol_meth '_' systmodel ver];

% Set FDP options: 
% choose regression model
if 0 %Parametric
    plymd          = 3;       % select parametric model, 1:3
    regmodel2start = 'param'; % regression model to start with (param, nonparam)
    poly_models    = {'quadratic','cubic','quartic'}; 
    poly_model     = poly_models{plymd};
else %Nonparametric
    regmodel2start = 'nonparam'; %regression model to start with (param, nonparam)
    poly_model     = []; 
end


%% Specify autocorrelated shocks to include and level. 
if multTCorrShk
    mzv = 0.5;  %scale of shocks.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Specify level of autocorrelation in the shock levels, [0,1], i.e. the weight on existing shock
    if 1;       m = .95;  
    elseif 0;   m = 1;
    elseif 0;   m = 0;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    % Control which shocks are turned off (=1) to explore individual effects
    % Case order: {noprofshock, nobiolshock, onlyKshock, onlyRshock, onlyPshock, onlyCshock}
    shockCase{1} = {0,0,0,0,0,0}; scNm{1} = 'Base';            scFileNm{1} = [];                    %Turned off: none
    shockCase{2} = {1,0,0,0,0,0}; scNm{2} = 'noprof';          scFileNm{2} = '_noprofshock';        %Turned off: profit
    shockCase{3} = {1,0,1,0,0,0}; scNm{3} = 'noprof, only K';  scFileNm{3} = '_noprofshock_onlyK';  %Turned off: profit and 2nd growth param (R or K0 for critdep)
    shockCase{4} = {1,0,0,1,0,0}; scNm{4} = 'noprof, only R';  scFileNm{4} = '_noprofshock_onlyR';
    shockCase{5} = {0,1,0,0,0,0}; scNm{5} = 'nobiol';          scFileNm{5} = '_nobiolshock';
    shockCase{6} = {0,1,0,0,1,0}; scNm{6} = 'nobiol, only P';  scFileNm{6} = '_nobiolshock_onlyP';
    shockCase{7} = {0,1,0,0,0,1}; scNm{7} = 'nobiol, only C';  scFileNm{7} = '_nobiolshock_onlyC';

    % Choose case for shocks to include.  
    js = 1;  %1:7 corresponding to list just above.
    noprofshock = shockCase{js}{1}; onlyKshock = shockCase{js}{3}; onlyRshock = shockCase{js}{4}; 
    nobiolshock = shockCase{js}{2}; onlyPshock = shockCase{js}{5}; onlyCshock = shockCase{js}{6}; 
    var = scFileNm{js};     

    casename = [casename '_multTCorrShk' num2str(mzv*100) '_serCorr' num2str(m*100) var]; 
end

if isempty(poly_model); pmnm = []; else; pmnm = ['_' poly_model]; end
if strcmp(sol_meth,'FDP'); casename = [casename '_' regmodel2start pmnm]; end

%% Specify nonparametric fitting function for fitrgp (Gaussian Process Regression)
kernfun = 'ardmatern52'; if strcmp(sol_meth,'FDP') && strcmp(regmodel2start,'nonparam'); casename=[casename 'ArdMat52']; end

%% Specify harvest cost function to use
if 1
    doConstMCHarv = 0; % default: MC decreasing in stock level
else
    doConstMCHarv = 1; 
    casename=[casename  '_CMC'];
end

%% Case specification complete
disp(['You are running case: ' casename])

%% Set the bioecon params
sc_set_bioecon_params_sf   % open sc_set_bioecon_params_sf

%% Specify discretized vectors: state, action, and stochastic process
% Set state vector. 
nN1         = 20;  % number of population states in discretization (N is continuous--nodes are along a continuous variable).  
% Set state node spacing parameters based on growth model.
switch systmodel
    case 'base'     %base model
        hd_lbub  = [0 20];          % high density area -- likely where there is more curvature.  right now lb must be 0 for code below.
        hds      = 3;               % 1=no change in density, multiples above 1 will enhance density here.
    case 'critdep' %critical depensation model
        hd_lbub  = [0 60];          % high density area -- likely where there is more curvature.  right now lb must be 0 for code below.
        hds      = 2;               % 1=no change in density, multiples above 1 will enhance density here.
end

if ~multTCorrShk  % For simple model (single state variable) will use finer grid for N1v at low stock levels 
    hd_def_sh= abs(diff(hd_lbub))/N_max;  % share of high definition "hd" area without additional emph
    hdp      = round(nN1*hds*hd_def_sh);  % num hd points
    N1v      = unique([linspace(0,hd_lbub(2),hdp) linspace(hd_lbub(2),N_max,nN1-hdp+1)]);   % hd points
elseif multTCorrShk
    switch systmodel
        case 'base'     %base model
            N1v = N_max*(linspace(0,1,nN1).^3); % The higher the exponent the denser the grid for lower values.             
        case 'critdep'  %critical depensation model
            N1v = N_max*(linspace(0,1,nN1).^1); 
        case 'rick'     %Ricker
            N1v = N_max*(linspace(0,1,nN1).^1); 
    end
end
N1v     = N1v(:);       % Ensure it's a column vector.
if ~multTCorrShk
    x_node  = [N1v]; 
    state_n = [nN1];    % number of nodes for each state variable    
else
    shkVec = @(ni) deal(linspace(1-mzv,1+mzv,ni)');
    %Numbers of nodes for shock states:
    nK = 9;  Kv = shkVec(nK);
    nR = 9;  Rv = shkVec(nR); 
    np = 9;  pv = shkVec(np); 
    nc = 9;  cv = shkVec(nc); 
    [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1v,Kv,Rv,pv,cv);     
    x_node = [N1nd(:), Knd(:), Rnd(:), pnd(:), cnd(:)];      
    clear N1nd Knd Rnd pnd cnd    % for memory
    state_n = [nN1 nK nR np nc];  % number of nodes for each state variable
end
nx      = size(x_node,2);      % number of state variables
xMinMax = [min(x_node); max(x_node)];

% Discretize action variable for FDP (*NOT CONTINUOUS* but very fine grid):
nA          = 1000;                     % # action nodes
Av          = linspace(0,1,nA);         % possible actions (value), escapement
Av(1)       = 1e-4;                     % minimum escapement.  Zero isn't feasible since cost is infinite.
Av = Av(:);                             % ensure it's a column vector


%% Set exogenous stochastic process
minz = .5; maxz = 1.5;  
Gz_base   = .1;  % Base case variance term

if  ~multTCorrShk
    % z ~ Normal(Uz,Gz): shock ~ truncated normal with mean Uz, var Gz, trunc: [minz, maxz].
    Uz   = 1; Gz   = Gz_base;
    PDF_norm = makedist('Normal',Uz,sqrt(Gz));  % Make normal distribution of shocks    
    % Truncate: 
    PDF_shock = truncate(PDF_norm,minz,maxz);   % viz: ezplot(@(x) pdf(PDF_shock,x),[.5,1.5])
elseif  multTCorrShk
    Uz   = 0;  % In this model these are disturbances to the shock level rather than the shock level itself.
    if m<1
        Gz = Gz_base*(1-m^2); 
    elseif m==1
        Gz = Gz_base*(1-.98^2); %Will look at variance manually
    end
    if Gz==0; error('Gz is zero'); end
    PDF_norm = makedist('Normal',Uz,sqrt(Gz));  % Make normal distribution of shocks    
    % No truncation for this case--will bound level elsewhere, not disturbance term here.
    PDF_shock = PDF_norm;                       % viz: ezplot(@(x) pdf(PDF_shock,x),[-.5,.5])   
end

%% Run solution method
% Initialize value function:
const     = 200;                  % value function intercept
slope_N   = 0.05;                 % slope across stock
if ~multTCorrShk
    coeffs = [slope_N]; 
    Vbar = const + coeffs(1)*N1v; 
    if 0
        display('debugging--using saved Vbar as initial guess')
        load([saveloc 'soln_FDP_base_multTCorrShk50_serCorr70_nonparam_rep_1.mat'],'Vbar'); %Replaces Vbar
    end
elseif multTCorrShk
    coeffs = [slope_N 1 -1 1 1];     % Linear coefficient guesses for N, p, c, K, R
    Vbar = const + coeffs*x_node';
end
Vbar = Vbar(:);             % Make column
ext       = x_node(:,1)==0; % Indicator: where population is extinct
Vbar(ext) = 0;              % insert 0 where extinct

%set up parallel pool. 
if doparfor 
    sc_setparllwrks; % open sc_setparllwrks. Generate parallel pool with a particular number of workers depending on system
    disp(['You are using ' num2str(poolobj.NumWorkers) ' workers'])
end  

% Run VFI or FDP script to find value function 
switch sol_meth
    case 'VFI'  
        sc_VFI_sf               % open sc_VFI_sf
    case 'FDP'  
        % Can loop for replicants to check for reliability of solution
        tempout=[];
        for repFDP = 1:10
            sc_FDP_parallel_sf  % open sc_FDP_parallel_sf  
        end
end




















