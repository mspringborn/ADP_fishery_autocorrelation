%sc_FDP_parallel_sf: script for FDP with parallel computing for simulations.

open sc_plots_sf  % This script creates a tracking plot to follow the FDP algorithm--having it open allows for pausing there if needed to make mid-run adjustments (e.g. with a breakpoint).

warning('off','MATLAB:mir_warning_maybe_uninitialized_temporary')  %supress warnings in parfor loop that temporary variables will be cleared at beginning of each loop.

%% FDP setup
sc_FDP_setup;  % Setup: dynamic step size, simulation parameters, and regression model
sc_FDP_shocks; % Setup: exogenous random shocks and variable paths

%% Pre-allocate and initialize arrays
% Pre-allocate:
[meanstep, maxdev, maxdevavg, switchstat_regmodel] = deal(zeros(1,max_sim/reg_every));                 
%meanstep:              Stores mean step size from a block for plotting (i.e. mean ss for "data" used in most recent regression/updating step)
%maxdev:                Stores deviation from one regression step to next (for all states) 
%maxdevavg:             Stores mean of recent max deviations for convergence checking
%switchstat_regmodel:   Store switching stat for regression model

% Initialize
n_extinct = 0;    % count of extinction events 
Vbar_prev = Vbar; % Vbar_prev is the previous estimate of Vbar before most recent update.  Used to assess deviation between updates, which is used to assess convergence
n_reg     = 1;    % regression counter
ss_movavg = 2*thresh_sw_ss;  % Stat for controling switch to decreasing SS; initialize above the threshold for switching.

%% Optional: 
% Use previously estimated model for speed/more informed start:
if 0
    if m==0;        case2Use = '_serCorr95_nonparamArdMat52'; 
    elseif m==.95;  case2Use = '_serCorr95_nonparamArdMat52';%'_serCorr95_nonparamArdratqWithJit'; 
    end
    temp = load([cd '\output\solutions\soln_FDP_critdep17_multTCorrShk50' case2Use '\soln_matfile'],'Vfit','txfun','powTx');
    Vfit = temp.Vfit; txfun = temp.txfun ; powTx = temp.powTx;
end

% Restart from stalled process with saved workspace
if 0 
    clear
    load('S:\temp430.mat')
end

%% Main FDP procedure: three nested loops
    %Outermost: loop over regression steps (value function updates) executed each time a block of simulations (size: reg_every*T) is complete
    %Middle:    loop over "reg_every" simulation chains
    %Innermost: loop over T periods 
tic

%%% Outermost loop:
while n_reg < max_n_reg && (maxdevavg(n_reg) > FDP_stoptol || n_reg==1) % keep going until max # simulations or convergence criterion is met
    %Pre-allocate outer loop arrays for storage of results
    [Vbar_blk, action_blk, shock_blk, stepst_blk] = deal(NaN*zeros(reg_every,T-1)); 
    states_blk = NaN*zeros(reg_every,T-1,nx);
    if multTCorrShk
         shock_blk = repmat(shock_blk,[1 1 numz]);             %expand to accomodate additional shocks
         shock_blk = reshape(shock_blk,size(shock_blk,1),[]);  %reshape to collapse dimensions 2 & 3 (needed for parfor)
    end
    
           
    % Set the stepsize: weight on "new information"
    if regmodel==1
        stepsize_n_reg = ss_0;
    elseif regmodel>1                                    % true after switch away from simple linear        
        if abs(ss_movavg) > thresh_sw_ss && n_reg<120    % If switching statistic is high, Vbar is still moving quickly, so keep high fixed stepsize (alpha0).  If n_reg is high then also switch.
            stepsize_n_reg = ss_0;                       % High fixed stepsize 
            if ind_dec_ss == 1                           % If using a dec stepsize but switchstat has jumped high, go back to constant stepsize.
                ind_dec_ss = 0;                          % Reset ind to 0=constant stepsize
            end
        else                                             % Switching stat is low, Vbar moving more slowly, use declining stepsize
            if ind_dec_ss == 0                           % If switching to a decreasing step size from a constant...
                ind_dec_ss  = 1;                         % Indicator: 1=declining stepsize
                n_sim_decss = n_sim;                     % Sim # at which switch to declining stepsize is made
            end  
            stepsize_n_reg = fi_stepsize(n_sim-n_sim_decss);    % Declining step size as n_sim grows past switching point
        end
    end
    
    %%% Middle loop over simulation chains:
   parfor n_sim_blk = 0:(reg_every-1)
  % Comment out parfor above and uncomment code below to run middle loop without parallel to explore/debug:
%    disp('you have turned parfor off!!!')
%    for n_sim_blk = 0:(reg_every-1)
        n_sim_pf= n_sim + n_sim_blk;      % n_sim_blk: sim # in block, n_sim_pf: sim # globally across all sims
        states  = state_set(n_sim_pf,:);  %starting state vector
        
        %% Innermost loop over T periods
        %Setup arrays to store simulation outcomes in a given time series
        [Vbar_t, action_t, shock_t, stepst_t] = deal(NaN*zeros(T-1,1));   states_t = NaN*zeros(T-1,nx);
        if multTCorrShk; shock_t = repmat(shock_t,[1 numz]); end
        for t = 2:T
            % Observe new level of stochastic variable(s)...and 
            % Calculate (conditional on action a=Av): 
                % pi_a:         Fishery profit
                % nextstates_a: Next period's N from this period's N
            if ~multTCorrShk
                z=shock_path(n_sim_pf,t);  
                [pi_a,nextstates_a]     = f_nextperiod_sf(z,states,Av,xMinMax,Gf,PI_netprof); %open f_nextperiod_sf
            else
                z=squeeze(shock_path(n_sim_pf,t,:));
                [pi_a,nextstates_a]     = f_nextperiod_multshock_sf(z,states,Av,xMinMax,Gf,PI_netprof_mult); %open f_nextperiod_multshock_sf
            end
                        
            % Calculate Vn_a: value of being at state in next period determined by each a_t: 
            switch regmodel
                case {1,2}  %Parametric models
                    Vn_a = max(0,fi_predict_cs(mdl,nextstates_a,xstd,xmean,Vstd,Vmean));                    
                case 3      %Non-parametric model
                    if ~multTCorrShk   % 
                        if n_sim==1    % before first nonparam model estimated.
                            Vn_a = const + coeffs(1)*nextstates_a;
                        else
                            if states(1) == 0 || all(nextstates_a==0)  % if N is already 0 or N is going to be 0 no matter what action
                                V_fitted = 0;  % fitted value given current state 
                                Vn_a     = zeros(size(nextstates_a));   
                            else
                                useCols = 1;
                                if ind_dec_ss %usePred % Fit using "predict"--accurate, slower. Use after switching to dec step size
                                    predData = txfun(nextstates_a);                          
                                    Vn_a = predict(Vfit,predData);
                                    states_use =states(:,useCols); states_use(:,1) = txfun(states_use(:,1));
                                    V_fitted=  max(0,predict(Vfit,states_use));
                                else  % Fit using interp & last set of state observations and fitted value function values. >3x faster.  
                                    Vn_a = interp1([0; fitd_nonpar_vals(:,1:nx)],[0; fitd_nonpar_vals(:,end)], nextstates_a,'pchip');  % Adding V(0)=0 to ensure origin included
                                    V_fitted=  max(0, interp1([0; fitd_nonpar_vals(:,1:nx)],[0; fitd_nonpar_vals(:,end)], states(:,useCols),'pchip'))
                                end
                            end 
                        end
                    elseif multTCorrShk  
                        if n_sim==1    % before first nonparam model estimated.
                            if 0  % Simple initial guess                               
                                Vn_a = const + coeffs(1)*nextstates_a + coeffs(2:5)*z(:); % 
                            elseif 1 % Informed guess
                                Vn_a = 500*(1-exp(-.23*nextstates_a)) + coeffs(2:5)*z(:); % 
                            elseif 0 % use prev est fitrgp model 
                                %Next code is a bit redundant with n_sim>1 code....
                                if states(1) == 0 || all(nextstates_a==0)  % if N is already 0 or N is going to be 0 no matter what action
                                    V_fitted = 0;  % fitted value given current state 
                                    Vn_a     = zeros(size(nextstates_a));   
                                else
                                    if m==0;     predData = txfun(nextstates_a);                          useCols = 1;
                                    elseif m>0;  predData = [txfun(nextstates_a) repmat(z(:)',[nA,1])];   useCols = 1:nx;
                                    end        
                                    Vn_a = predict(Vfit,predData); 
                                    V_fitted=  max(0,predict(Vfit,states(:,useCols)));
                                end   
                            end
                        else % For all sims after the first one:
                            % get nonparametric V for all potential future states given a (Vn_a).  And for starting state vector "states" (V_fitted)
                            if states(1) == 0 || all(nextstates_a==0)  % if N is already 0 or N is going to be 0 no matter what action
                                V_fitted = 0;  % fitted value given current state 
                                Vn_a     = zeros(size(nextstates_a));   
                            else
                                if m==0;     predData = txfun(nextstates_a);                          useCols = 1;
                                elseif m>0;  predData = [txfun(nextstates_a) repmat(z(:)',[nA,1])];   useCols = 1:nx;
                                end
                                Vn_a = predict(Vfit,predData);
                                states_use =states(:,useCols); states_use(:,1) = txfun(states_use(:,1));
                                V_fitted=  max(0,predict(Vfit,states_use));
                            end                           
                        end
                    end
                    %viz: 
                    %figure(117); clf;
                    %plot(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2),'k.-'); xlabel('N'); ylabel('V'); grid on; hold on
                    %x_fine=linspace(0,max(x_node),1e5); plot(x_fine,interp1(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2), x_fine,'pchip'), 'r.-')
                    %plot(x_fine,interpn(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2), x_fine,'spline'), '.-'); %
                    %viz: x_fine=linspace(0,max(x_node),1e5); figure(117); plot(x_fine,interpn(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2), x_fine,'cubic'), '.-'); %!blip!
            end
            % Check for problems with Vn_a:
            if ~all(Vn_a>0)
                if all(Vn_a>=0)
                else  % display('Vn_a is negative or NaN.');
                    %figure(117); plot(nextstates_a,Vn_a,'.-'); hold on; plot(nextstates_a(Vn_a<0),Vn_a(Vn_a<0),'*r') 
                    Vn_a(Vn_a<0) = 0;
                end
            end

            Vn_a = reshape(Vn_a, size(pi_a));  %Ensure that Vn_a and pi_a vectors are same orientation.
            % Calc PV of each possible action 
            V_a  = pi_a + delta*Vn_a;    %viz: figure(77); plot(Av,delta*Vn_a','.-'); xlabel('action'); ylabel('delta*Vn_a'); 

            % Identify maximized value and index of optimal action.
            [Vtilde, action]        = max(V_a(:));
             % Check for problems with identification of optimum
            if sum(V_a==Vtilde)>1 
                if strcmp([systmodel sol_meth],'critdepFDP') % For this case there are very low stock levels (<1e-13) that can lead to same value over actions to given precision.
                    tempvec     = find(V_a==Vtilde);         % All that match the max to given precision
                    [~,tempind] = max(pi_a(tempvec));        % the one with the highest immediate profit
                    action      = tempvec(tempind);
                    Vtilde      = V_a(action); 
                elseif multTCorrShk && Gf(z(1),z(2),states(1))<1e-6 
                    Vtilde=0; action=1; % stock went to zero
                else
                    % Solution is not unique: save and stop
                    f_parForFailSave('maxActNotUnique',V_a,Vtilde,n_sim_blk,Gf,z,systmodel,sol_meth,multTCorrShk,pi_a,delta,Vn_a,nextstates_a,states); % open f_parForFailSave
                    error('Max action is not unique');
                end
            end 
            if Vtilde <0;          error('Vtilde < 0.');              end %not a fatal problem but should not be part of final solution.
%             if n_reg>0 && n_sim_blk ==N1stop 
%                  %visualize:
%                  figure(83); clf
%                  subplot(1,3,1); plot(Av,V_a,'.-'); hold on; plot(Av(action), V_a(action),'r*'); xlabel('action'); ylabel('V_a'); grid on
%                     title(['N, n-reg = ' num2str([N1v(N1stop) n_reg])]) 
%                  subplot(1,3,2); plot(Av,pi_a,'.-'); hold on; plot(Av(action), pi_a(action),'r*'); xlabel('action'); ylabel('pi_a'); grid on
%                  subplot(1,3,3); plot(Av,delta*Vn_a','.-'); hold on; plot(Av(action), delta*Vn_a(action),'r*'); xlabel('action'); ylabel('delta*Vn_a'); grid on
%                  N1v(N1stop)
%             end

            % Update value function; save values and states for regression step
            % Vbar: store a convex combination of (1) predicted V_fitted based on existing mdl, and (2) new observations, Vtilde
            switch regmodel
                case {1,2}  %Parametric models
                    V_fitted = max(0,fi_predict_cs(mdl,states,xstd,xmean,Vstd,Vmean)); 
                case 3      %Non-parametric model
                    if ~multTCorrShk  
                        %V_fitted = interp1(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2), states,'pchip'); 
                        if n_sim==1
                            V_fitted = const + coeffs*states(:);  %if using pre-exisitng cgam to start  this is undesirable overwrite.
                        else
                            % Already completed with prediction step further above 
                        end
                    elseif multTCorrShk
                        if n_sim==1
                            V_fitted = const + coeffs*states(:);  
                        else
                            % Already completed with prediction step further above 
                        end
                    end
            end
            % Smoothing step, apply stepsize
            Vbar_t(t-1) = (1-stepsize_n_reg) * V_fitted  +  stepsize_n_reg * Vtilde;      
            % Store output
            states_t(t-1,:) = states;     action_t(t-1) = action;
            stepst_t(t-1) = stepsize_n_reg;

            if ~multTCorrShk; shock_t(t-1)   = z; 
            else              shock_t(t-1,:) = z(:)'; 
            end
            
            % Update current state array for next period based on optimal action.
            if ~multTCorrShk; states = nextstates_a(action,:);  
            else              states = [nextstates_a(action,:) z(:)'];
            end
        end  % end of innermost loop
        % Store innermost loop output
        Vbar_blk(n_sim_blk+1,:)   = Vbar_t;        states_blk(n_sim_blk+1,:,:) = states_t;   % states_t assignment: robust to single state case?
        action_blk(n_sim_blk+1,:) = action_t;      stepst_blk(n_sim_blk+1,:)   = stepst_t;   
        shock_blk(n_sim_blk+1,:)  = shock_t(:);   
    end % end of middle loop
    if multTCorrShk
        %parfor requires shock_blk to stay a matrix (above): [sim,([T-1] x #shocks)]. Reshape to array: [sim,[T-1],#shocks)] 
        shock_blk = reshape(shock_blk,size(shock_blk,1),T-1,numz);  %
        % Note for multTCorrShk, equiv to just grabbing: shock_path(n_sim:(n_sim+(reg_every-1)),2:); % Just grab the appropriate section of stored shock levels.    
    end
    %error checking
    if ~all(Vbar_blk(:)>=0);        error('sc_FDP_sf: Vbar_blk is negative.');     end
    if ~all(~isnan(states_blk(:))); error('sc_FDP_sf: states_blk NaN problem');    end
    % count extinctions
    n_extinct = n_extinct + sum(states_blk(:,end,1)==0);
    
    %Collapse sims (reg_every) and time (T-1) into 1 dimension
    Vbar_blk   = reshape(Vbar_blk,  [],1);   states_blk = reshape(states_blk,[],nx);  % collapse 1st two cols       
    action_blk = reshape(action_blk,[],1);   stepst_blk = reshape(stepst_blk,[],1);
    shock_blk  = reshape(shock_blk,[],size(shock_blk,3));  % collapse 1st two dimensions
       
    %Update global sim counter (how many total simulation chains have been run since begining) 
    n_sim = n_sim+reg_every-1;              % 
   
    %% If simulations in regression block are complete, run regression to incorporate new information into value functio
% !!! check: is this if statement redundant? Always triggered when a block is done?!
    if n_sim/reg_every == round(n_sim/reg_every)  % if this is a regression iteration 
%         if 1 % show mean profit in T in sims?
%             display(['mean profit:' num2str(mean(getProfT(getProfT(:,2)>20,1))) ]);
%         end             
        n_reg = n_sim/reg_every;  % regression number (counter)
       
        % Visualize existing estimate of V and new data 
        %fig=20; sc_plots_sf;
        
        % Store last regression coeff vector before overwriting with new estimate
        if strcmp(regmodel2start,'param');     coefficients(1:length(beta0),n_reg) = beta0';   end

        % Control regression model flag progression:   linear (1) --> nonlinear (2) --> nonparm (3)
        if n_reg>1 && regmodel < 3  % not at first regression && we haven't switched to nonparm
            % stay with current model until a sufficient number of regressions run and constant term relatively stable:
            if regmodel==1 && abs(switchstat_regmodel(n_reg-1)) < thresh_sw_regmdl
                regmodel=after_regmodel1;
                nswitch=n_sim;  %just do this once at the switch else stepsize never falls.
            end
        end

        %% Regression:  y = f(x), where y = Vbar_blk  &   x = states_blk.
        % Delete extraneous rows for cases where stock went to zero (coded as -9999)
        if sum(states_blk(:)==-9999)>0 
            Vbar_blk(states_blk(:,1)==-9999)  =[];
            states_blk(states_blk(:,1)==-9999,:)=[];
        end
        % Check: for NaN problems in data:
        if sum(isnan(states_blk'*Vbar_blk))>0; error('NaN problems in states_blk and/or Vbar_blk'); end
        
        % run regression
        if regmodel<3               % do parametric regression
            sc_param_reg_sf         % open sc_param_reg_sf  
        else                        % do nonparametric regression
            sc_nonpar_reg_sf_fitrgp % open sc_nonpar_reg_sf_fitrgp
        end
        
        %viz:
%         figure(117); clf;
%         plot(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2),'k.-'); xlabel('N'); ylabel('V'); grid on; hold on
%         plot(N1v, Vpred_blk_aug(end-(length(x_node)-1):end),'r.-');       
 
        % Check Vbar: any negative values?
        if ~all(Vbar>=0) %If not all values are >=0
            display('sc_FDP_sf: There are negative fitted values for Vbar (at nodes).  Setting min Vbar equal to zero.'); 
            mmv = ([  [min(x_node(Vbar<0)); max(x_node(Vbar<0))]...
                      [min(Vbar(Vbar<0));   max(Vbar(Vbar<0))  ] ]);
            display(array2table(mmv,'VariableNames',{'Stock' 'Value'}));
            Vbar(Vbar<0)=0;      
        end
        
        %% Post regression: store values and calculate convergence metrics
        %viz_fig=117; viz_FDP;
        %viz_fig=118; viz_FDP;

        % Calculate and store convergence metrics:
        devraw              = 100*(Vbar - Vbar_prev)./(Vbar_prev);              % deviation (in percent) between iterations
        devraw_all(:,n_reg) = devraw;                                           % store for examination/troubleshooting (i.e. where are any large deviations concentrated?
        excl_smallV         = (Vbar < excl_thres) | (Vbar_prev < excl_thres);   % small values of V to exclude from convergence statistic -- % change metric very sensitive at low values.
        maxdev(n_reg)       = max(abs(devraw(~excl_smallV)));                   % get metric for checking convergence criterion 
        % Convergence metric is the moving average over the last 10 periods (or all avail if <10):
        maxdevrec        = maxdev(max(1,n_reg-9):n_reg); % recent max deviations 
        maxdevavg(n_reg) = mean(maxdevrec);              % mean of recent max deviations
        
        % Set the switching statistic for the regression model determining shift from linear to non-linear: mean deviation in V between updates.
        if regmodel < 3
            switchstat_regmodel(n_reg) = switchstat_regmod_fun(devraw,excl_smallV);         % there will be a NaN at N=0 due to V(N=0)=0
        end    
                
        % Set switching statistic for evaluating switch to decreasing stepsize.
        ss_stepsize_met(n_reg) = ss_movavg;
        switchstat_stepsize = switchstat_ss_fun(Vbar,Vbar_prev); 
        ss_stepsize(n_reg) = switchstat_stepsize;
        if n_reg < 6  % For the first few regressions keep stat high to avoid switching
            ss_movavg = 2*thresh_sw_ss;
        else  
            %get moving average of switch stat from last 6 periods.
            ss_movavg = mean(abs(ss_stepsize(n_reg-5:n_reg))); 
        end              
        meanstep(n_reg)    = mean(stepst_blk);        % store mean step size from iteration (for plotting/assessment)

        % FDP tracking figure: shows objects as they update: value function, constant term from V model, max-%dev, step-size, other coefficients, history of deviations.
        if repFDP == 1 % && n_reg > 60
            % Display tracking status in command window        
            disp(['Deviation stat: ' num2str(maxdevavg(n_reg))])
            disp(['Step size:      ' num2str(stepsize_n_reg)  ]);
            if 1
                fig=1; sc_plots_sf  % open sc_plots_sf
            end
        end
        if 0 %turn this on to get mid-solution results saved for various functional forms.
            display('Breaking early to generate mid-solution results')
            if n_sim>=1500
                if regmodel==3
                    mod='Non-parametric';  
                else
                    if strcmp(valuefun_late,poly2);     mod='Quadratic'; 
                    elseif strcmp(valuefun_late,poly3); mod='Cubic';
                    elseif strcmp(valuefun_late,poly4); mod='Quartic';
                    end
                    fitd_nonpar_vals=[];
                end
                save(['output\vf_mid_rez_' mod '.mat'],'states_blk', 'Vbar_blk' , 'valuefun_late', 'n_sim', 'T', 'mod','fitd_nonpar_vals','x_node','Vbar');
                returnf
            end
        end
        % Update Vbar_prev
        Vbar_prev = Vbar;     % Store updated estimate of val fun as V, s.t. Vbar can be updated next iteration. 
    end % end regression step
    n_sim = n_sim+1; % update regression/update counter
end

time4fdp = toc
close all
%clear shock_path randindx state_set FDPoutputtable  %clear large unnecessary variables before save

%% Save solution
if 1
    clear shock_path randindx state_set FDPoutputtable  %clear large unnecessary variables before save
    if ~multTCorrShk
        dest_soln = [saveloc 'solutions\soln_' casename '_rep_' num2str(repFDP)];   
        save(dest_soln)       % Save Matlab workspace
    elseif multTCorrShk
        dest_soln = [saveloc 'solutions\soln_' casename '\'];  mkdir(dest_soln)
        save([dest_soln 'soln_matfile'])  
    end
end
%% Diagnostics
if 0
    
%     dest_soln = [saveloc 'solutions\soln_' casename '\'];  mkdir(dest_soln)
%     save([dest_soln 'temp_soln_matfile'])                      
    
% Look at where the biggest average absolute residuals are for final TL periods
TL = (n_reg-50):n_reg; %periods to examine.
%TL = 1:50; %periods to examine.
t2 = (devraw_all(:,TL)); %t2(1:10,1:10)   percentage deviations in V for TL periods, all nodes.
t3 = sortrows([mean(abs(t2),2) [1:length(devraw_all)]'],-1);%1,'descend');
t3(isnan(t3(:,1)),:) = []; %Drop NaNs
% t3: col 1 is mean devraw over final TL periods, col 2 is recno of x_node
figure(11); plot(t3(1:1000,1)); %plots the highest 
x_nodeBigResid = x_node(t3(:,2),:); open x_nodeBigResid  % to inspect, x_nodes of biggest residuals
x_nodeBigResidEx = x_nodeBigResid(x_nodeBigResid(:,1)<N1v(nN1),:); open x_nodeBigResidEx %Most big residuals were at high N... what's next?
figure(12); plot(1:4,x_node(t3(1:100,2),2:5),'.-'); %plot z's for highest deviations
figure(13); histogram(Vbar(t3(1:1000,2)))
t22 = t2( ~isnan(t2(:,end)) & ~isinf(t2(:,end)),end); t22(1:100)
figure(14); histogram(t22); ylim([0,10])
%~isinf(t2) &
Nnxt = Gf(x_node(:,2),x_node(:,3),x_node(:,1)); open Nnxt
temp = [Nnxt Vbar]; open temp


end


%% POLICY FUNCTION & Final GRAPHS
if 0
    sc_policyfun_and_figs_sf
end














