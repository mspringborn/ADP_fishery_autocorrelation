%sc_FDP_setup
%Setup: dynamic step size, simulation parameters, and regression model

%% Step size (SS): determines weight placed on "new information" for value function each iteration     
% SS starts at ss_0, then once Vbar updates are "small" (see switchstat_ss_fun) ss starts to fall over iterations, with ss_lb as lower bound.
ss_0                = 0.85;    %step size to start
ss_lb               = 0.001;   %step size lower bound
switchstat_ss_fun   = @(Vbar,Vbar_prev) 100*mean(Vbar - Vbar_prev)./mean(Vbar_prev); % mean dev as % of mean value-->  statistic for switching from constant step size (ss_0) to decreasing: 
ind_dec_ss          = 0;       % Indicator for decreasing stepsize: 0=constant, 1=decreasing in number of simulations. 

%sp_rate     : step size decline rate
%thresh_sw_ss: set threshold for switching to decreasing step size (units: absolute value of the mean %-deviation in V between updates at the nodes). 
    % -->set level by running with level set to eps and see where metric levels off (tracking figure). Then consider multiple FDP runs--if there are outliers (and esp if between run deviations are all one direction in important part of state space before switch...need to tighten.) If algorithm doesn't switch permanantely  to declining, need to loosen.
%excl_thres  : V level up to which deviations are ignored in convergence stat (%-change in small V levels--e.g. where stock is almost zero--is too noisy)
switch systmodel
    case 'base'     %base model
        excl_thres   = eps;
        if ~multTCorrShk     
            sp_rate      = 2e-4;
            FDP_stoptol  = 0.004;
            thresh_sw_ss = 0.15;    % Set to eps to start; see where switchstat levels, then set this trigger just above that.
        elseif multTCorrShk  
            sp_rate      = 1e-4;   
            FDP_stoptol  = 0.75;   
            thresh_sw_ss = 0.3;  
            if m==0 
                if    ~doConstMCHarv; thresh_sw_ss = 0.25; 
                elseif doConstMCHarv; thresh_sw_ss = 0.35; 
                end
                FDP_stoptol  = 0.025; 
            end 
        end

    case 'critdep' %critical depensation model
        excl_thres   = 5;       
        if ~multTCorrShk  
            sp_rate      = 2e-4;
            thresh_sw_ss = 0.3; 
            FDP_stoptol  = 0.325;
        elseif multTCorrShk  
            sp_rate      = 1e-4;
            if m==0;    
                FDP_stoptol  = 0.25;
                if ~doConstMCHarv;
                    thresh_sw_ss = 0.55;  
                elseif ~doConstMCHarv;
                    thresh_sw_ss = 0.65;
                end
            elseif m>0; 
                thresh_sw_ss = 0.95; 
                FDP_stoptol  = 0.017;
            end
            if m==.95 && doConstMCHarv; thresh_sw_ss = .9; end
        end

    case 'rick'     %
        excl_thres   = eps;
        sp_rate      = 1e-4;   
        FDP_stoptol  = 0.75;  
        thresh_sw_ss = 0.25;   
        if m==0; FDP_stoptol  = 0.025; end 
end

% Specify dynamic step size function, decreases over the number of simulations
fi_stepsize = @(iter) max(ss_0*(exp(-sp_rate.*iter)),ss_lb);  % from Hull.  Powell: max(alpha0*(1+bstep/alpha0 + astep)/(bstep/visit+astep + visit^betastep),0.05);

%% FDP simulation parameters
n_sim           = 1;   % simulation count
T               = 2;   % number of periods per iteration (inner loop, t=1,...,T)
% reg_every: run smoothing regression every __ iterations, num sims in a block
% max_sim:    max number of iterations, ensures it's a multiple of reg_every.
switch systmodel
    case {'base','rick'}
        if    ~multTCorrShk; reg_every = (nN1-1)*30;  % Reducing sims per regression step increases speed but hurts precision.
        elseif multTCorrShk; reg_every = 400; 
        end
    case 'critdep' 
        reg_every   = (nN1-1)*30;%16;
end
max_n_reg   = 400; % Set maximum number of regression steps allowed before terminating
max_sim     = max_n_reg*reg_every;  
        
%% FDP Regression setup -- depending on parametric or non-parametric approach
switch regmodel2start
    case 'param'        % Functional Forms of Value Function for Initialization & Regressions
        regmodel            = 1;    % Indicator for regression model (1: parametric-linear model, 2: parametric-nonliner, 3:non-parametric)
        nswitch             = [];   % isempty(nswitch)-->true until the switch away from simple linear.
        after_regmodel1     = 2;    % After regmodel=1, switch to either 2:parametric-nonlinear or 3:non-param.
        fitd_nonpar_vals    = [];   % Necessary only for nonparam.  Set empty so parallel process can execute
        
        switchstat_regmod_fun = @(devraw,excl_smallV) nanmean(devraw(~excl_smallV));   %devraw        = 100*(Vbar - Vbar_prev)./(Vbar_prev);
        thresh_sw_regmdl    = 0.5;  % threshold for switching regression model (units: mean percentage deviation in V between regressions)
        
        switch poly_model   % specify type
        case 'quadratic'; valuefun_late = 'y ~ 1 + x1 + x1^2';
        case 'cubic';     valuefun_late = 'y ~ 1 + x1 + x1^2 + x1^3';
        case 'quartic';   valuefun_late = 'y ~ 1 + x1 + x1^2 + x1^3 + x1^4';
        end
        valuefun=valuefun_late;
        max_num_coeff = 5; % max number of coefficients in largest model (ok if oversized)
        % Initialize the regresion model (mdl), regress Vbar against state variables, so that first iteration below will run.
        Vstd  = 1; %std(Vbar(~ext));        
        Vmean = 0; %mean(Vbar(~ext));
        % Get stats for centering and scaling data 
        xstd  = std(x_node); %std(x_node(~ext,:));  
        xmean = mean(x_node); %[0 0 0];%mean(x_node(~ext,:));
        valuefun_init = 'y ~ 1 + x1';
        % Helper functions for centering (subtract mean) and scaling (divide by SD) the data (simulated observations) -- stabilizes regression step.
        fi_rep        = @(xdata,xstat) repmat(xstat,size(xdata,1),1);                         %replicates xstat vector to match length of xdata. xstat = mean or std
        fi_cs         = @(xdata,xmean,xstd) (xdata-fi_rep(xdata,xmean))./fi_rep(xdata,xstd);  %centers and scales
        fi_predict_cs = @(mdl,xdata,xstd,xmean,Vstd,Vmean) predict(mdl,fi_cs(xdata,xmean,xstd))*Vstd + Vmean;  %predicts with centering and scaling.

        mdl   = fitlm(fi_cs(x_node,xmean,xstd),fi_cs(Vbar,Vmean,Vstd),valuefun_init);     
        beta0 = mdl.Coefficients.Estimate;
        %pre-allocate variables to store output from regressions that take place every reg_every iteration
        coefficients = zeros(max_num_coeff,max_sim/reg_every);    % Stores regression coefficients                               
    case 'nonparam'   % in this case going straight to non-param
        regmodel         = 3;   
        nswitch          = 1; 
        fitd_nonpar_vals = [x_node Vbar(:)];  %Need to initialize model simply (e.g. linear) for first regression block.  After that these values are estimated from non-param regression. 

end
