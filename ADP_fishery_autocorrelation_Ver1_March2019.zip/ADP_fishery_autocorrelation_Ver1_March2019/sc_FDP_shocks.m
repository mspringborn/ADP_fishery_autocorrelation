%sc_FDP_shocks.m
%Setup exogenous random shocks and variable paths: for each, generate (1) stochastic draws, and (2) starting points and paths.

%% (1) stochastic draws
if ~multTCorrShk
    shock_path = random(PDF_shock,max_sim,T);
elseif multTCorrShk
    PI_netprof_mult = PI_netprof_multTCorrShk;
    % Shocks to stochastic state variables
    numz = 4; % Number of shock variables
    % Shock path disturbance is mean zero (not mean 1) since these are disturbances to an autoregressive process (regressing to 1).
    shock_path_disturb = random(truncate(PDF_norm,-mzv,mzv),max_sim,T,numz);   % Dim: max_sim x T x numz
    shock_path_disturb(:,1,:) = NaN; % shock_path for time t=1 not used.
end
      
%% (2) starting points (t=1) and paths
%Starting points: select some deterministically to ensure state space coverage, then randomly.
if ~multTCorrShk
    state_set = zeros(max_sim,numel(state_n));   % ndims(statespace{1}));
    for j = 1:numel(state_n)                                % Loop through state variables
        if 1
            N1SampLb=0.5;
            %state_set(:,j) = x_node(indx_lb,j) + rand(max_sim,1)*diff(x_node([indx_lb end],j)); % Uniform random between x_node(indx_lb,j) and x_node(end,j)
            state_set(:,j) = N1SampLb + rand(max_sim,1)*(x_node(end,j)-N1SampLb); % Uniform random between x_node(indx_lb,j) and x_node(end,j)
            %oversample around constant escapement outcome. Only feasible after solving once for approximate constant escapement level.
            if 0                                     % Did not use this option but could be helpful in some applications to emphasize typical states.
                ovrSmpSh  = 0.2;                     % oversampling share
                ovrSmpNum = round(max_sim*ovrSmpSh); % Number of samples dedicated to oversampling near typical states
                rngPM = .07;                         % Const Esc plus growth level and plus/minus range to oversample from. 
                switch systmodel
                    case 'base'  
                        CEwG = Gf(72);
                    case 'critdep'
                        CEwG = Gf(75); 
                end
                % Next 2 lines: get index (indPut) to place blocks of "oversamples" in each chunk that will comprise a given set for regression.
                oSperReg = ovrSmpNum/reg_every;       % Oversamples per reg
                indPut   = repmat([1:oSperReg]',[1,reg_every]) + repmat(reg_every*[0:(reg_every-1)],[oSperReg,1]);
                state_set(indPut(:),j) = CEwG*(1-rngPM) + rand(ovrSmpNum,1)*CEwG*(2*rngPM);
            end
        else       
            if j==1 && N1v(1)==0                                % Set lower bound of indices for starting
                indx_lb = 2;                                    % exclude population N=0 as a starting state
            else
                indx_lb = 1;
            end
            randindx = randi([indx_lb state_n(j)],max_sim,1);   % random indicies in the state space
            state_set(:,j) = x_node(randindx,j);                % ...converted to corresponding random levels
            ssj_temp = reshape(state_set(:,j),[reg_every length(state_set)/reg_every]);   % reshape into block, #rows = reg_every
            %make deterministic selection of each node nd times then rest random.
            num_nonzero_nds = sum(x_node(:,j)>0); %number of non-zero state nodes (N = 0 has a value, V, of zero and are handled separately).
            nd=reg_every/num_nonzero_nds;
            if num_nonzero_nds*nd>reg_every; error('number of nodes too great, length of block too small to accomodate # of deterministic node selections below'); end
            ssj_temp(1:num_nonzero_nds*nd,:) = repmat(x_node(x_node(:,j)>0,j),[nd length(state_set)/reg_every]);
            state_set(:,j) = reshape(ssj_temp,[length(state_set) 1]);  clear ssj_temp;      % return to shape
        end
    end
elseif multTCorrShk
    % With multTCorrShk, there are multiple states and MANY more potential starting nodes.  
    % Approach below: randomize all possible starting states in the grid (that have a positive stock) and cycle through that randomized list.
    nzRows  = find(x_node(:,1)~=0);                     % Indices of N>0 rows
    nnzR    = length(nzRows);
    rI      = randperm(nnzR);                           % Random ordering of indices of N>0 rows
    numreps = max_sim/nnzR;                             % How many copies of the random ordering will fit in max_sim simuluations.
    randInd = repmat(rI(:),[floor(numreps),1]);         % Get the whole copies of the list.
    addRows = max_sim-length(randInd);                  % How many rows in the remaining fraction of the list to get to max_sim
    randInd = [randInd; rI(1:addRows)'];                % Combine complete and partial list.
    randIAct= nzRows(randInd);                          % Convert from random indices of N>0 rows to row numbers in x_node   
    state_set = x_node(randIAct,:);                     % Convert to actual state levels.    
    
    % For nonparametric regression fitting ensure no extrapolation error by ensuring bounds are present for each variable in reg model (note that
    % bounds for K,RK0, p and c will individually be present given randomization above (small vectors. 
    for j = 0:(-1+length(state_set)/reg_every)
        b = j*reg_every; %Increment for row indices to catch begining over every block (size reg_every).
        state_set(1+b,1) = N1v(1);                             % stock
        state_set(2+b,1) = N1v(end); 
        state_set(3+b,1) = N1v(1);   state_set(3+b,2) = Kv(1);    % zk*stock
        state_set(4+b,1) = N1v(end); state_set(4+b,2) = Kv(end); 
        state_set(5+b,1) = N1v(1);   state_set(5+b,3) = Rv(1);    %  zrk0*stock
        state_set(6+b,1) = N1v(end); state_set(6+b,3) = Rv(end);
        state_set(7+b,1) = N1v(1);   state_set(7+b,4) = pv(1);    %  zp*stock
        state_set(8+b,1) = N1v(end); state_set(8+b,4) = pv(end);
        state_set(9+b,1) = N1v(1);   state_set(9+b,5) = cv(1);    %  zc*stock
        state_set(10+b,1) = N1v(end); state_set(10+b,5) = cv(end);
        state_set(11+b,2) = Kv(1);   state_set(11+b,3) = Rv(1);    %  zk*zrk0
        state_set(12+b,2) = Kv(end); state_set(12+b,3) = Rv(end);
        state_set(13+b,4) = pv(1);   state_set(13+b,5) = cv(1);    %  zp*zc
        state_set(14+b,4) = pv(end); state_set(14+b,5) = cv(end);        
        state_set(15+b,2) = Kv(1);   state_set(15+b,4) = pv(1);    %  kp
        state_set(16+b,2) = Kv(end); state_set(16+b,4) = pv(end);
        state_set(17+b,2) = Kv(1);   state_set(17+b,5) = cv(1);    %  kc
        state_set(18+b,2) = Kv(end); state_set(18+b,5) = cv(end);
        state_set(19+b,3) = Rv(1);   state_set(19+b,4) = pv(1);    %  rp
        state_set(20+b,3) = Rv(end); state_set(20+b,4) = pv(end);
        state_set(21+b,3) = Rv(1);   state_set(21+b,5) = cv(1);    %  rc
        state_set(22+b,3) = Rv(end); state_set(22+b,5) = cv(end);
    end   
    if 1  % Add random jitter to move starting points off of grid.       
        for j=1:size(state_set,2)
            if j==1; Xv=N1v; elseif j==2; Xv=Kv; elseif j==3; Xv=Rv; elseif j==4; Xv=pv; elseif j==5; Xv=cv; end
            if j==1 && ~all(diff(Xv)==diff(Xv(1:2)))
                for i=1:length(state_set(:,j))
                    Xvi = find(Xv == state_set(i,j)); %index of state in Xv
                    if Xvi>1 && Xvi<length(Xv)  %If not a boundary point.
                        state_set(i,j)=Xv(Xvi-1) + rand*diff(Xv([Xvi-1 Xvi+1])); %Replace with random point between node above and below.
                    end
                end
            else
                discWidth = diff(Xv(1:2));  % Note: this only works well since grid spacing is uniform!  Otherwise needs adjustment.
                jitBy   = discWidth*rand([size(state_set,1),1])-discWidth/2; 
                isBndry = state_set(:,j)==xMinMax(1,j) | state_set(:,j)==xMinMax(2,j); %ind for boundary case
                state_set(:,j) = state_set(:,j) + (~isBndry).*jitBy; 
            end
            state_set(:,j) = min(state_set(:,j),xMinMax(2,j));  %Reimpose min and max.
            state_set(:,j) = max(state_set(:,j),xMinMax(1,j));
        end
    end
    % Get full simulated paths for temporally correlated shock levels since they're exogenous
    shock_path        = NaN*ones(max_sim,T,numz);
    shock_path(:,1,:) = state_set(:,2:end);  % set shock level to initial state
    for t=2:T
        shock_path(:,t,:) = fi_shockNextSerCorr(shock_path(:,t-1,:), shock_path_disturb(:,t,:)); 
        % Impose bounds:  CRITICAL: simple version here must be extended if bounds on shocks differ
        shock_path(:,t,:) = max(xMinMax(1,2),shock_path(:,t,:));  %Impose lower bound
        shock_path(:,t,:) = min(xMinMax(2,2),shock_path(:,t,:));  %Impose upper bound       
    end    
%     figure(7); clf; subplot(2,1,1); plot(1:T, shock_path(6:10,:,1),'-')
%                     subplot(2,1,2); plot(1:T, shock_path_disturb(6:10,:,1),'-')
    clear shock_path_disturb
end