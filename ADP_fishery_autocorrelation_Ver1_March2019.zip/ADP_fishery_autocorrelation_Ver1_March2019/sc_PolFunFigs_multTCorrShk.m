% sc_PolFunFigs_multTCorrShk
% generate policy function figs for multTCorrShk case

%% figure(1); 
mPt  = round([nN1,nK,nR,np,nc]/2);                  %mid-points of state vectors

L1  = 'all z^i=1'; xNdCs1  = [NaN,mPt(2),mPt(3),mPt(4),mPt(5)];  
L2  = 'min z^K';  xNdCs2  = [NaN,1     ,mPt(3),mPt(4),mPt(5)];  % plot data: escapement
L3  = 'max z^K';  xNdCs3  = [NaN,nK    ,mPt(3),mPt(4),mPt(5)];  % plot data: escapement
L4  = 'min z^R';  xNdCs4  = [NaN,mPt(2),1     ,mPt(4),mPt(5)];  % plot data: escapement
L5  = 'max z^R';  xNdCs5  = [NaN,mPt(2),nR    ,mPt(4),mPt(5)];  % plot data: escapement
L6  = 'min z^p';  xNdCs6  = [NaN,mPt(2),mPt(3),1     ,mPt(5)];  % plot data: escapement
L7  = 'max z^p';  xNdCs7  = [NaN,mPt(2),mPt(3),np    ,mPt(5)];  % plot data: escapement
L8  = 'min z^c';  xNdCs8  = [NaN,mPt(2),mPt(3),mPt(4),1     ];  % plot data: escapement
L9  = 'max z^c';  xNdCs9  = [NaN,mPt(2),mPt(3),mPt(4),nc    ];  % plot data: escapement
% Choices for max/min esc taken from figure 6 at bottom
if m==.95 || m==1
    disp('Need to correct for m==1')
    casecheck = [systmodel '_' npaltCase]; 
    if     strcmp('base_ArdMat52',casecheck);           setmin = [NaN,1,nR,np,1]; setmax = [NaN,nK,1,1,nc];
    elseif strcmp('critdep_ArdMat52',casecheck);        setmin = [NaN,1,1,1,nc];  setmax = [NaN,nK,nR,np,1];
    elseif strcmp('base_ArdMat52_CMC',casecheck);       setmin = [NaN,1,nR,np,1]; setmax = [NaN,nK,1,1,nc];
    elseif strcmp('critdep_ArdMat52_CMC',casecheck);    setmin = [NaN,1,1,1,nc];  setmax = [NaN,nK,nR,np,1];
    end
    L10 = 'min esc'; xNdCs10 = setmin; 
    L11 = 'max esc'; xNdCs11 = setmax;    %  
elseif m==.5
    L10 = 'min esc'; xNdCs10 = [NaN,1,1,np,1]; 
    L11 = 'max esc'; xNdCs11 = [NaN,nK,nR,1,nc]; 
elseif m==0  % this is not needed for M=0 case but specified so code below runs 
    L10 = 'min esc'; xNdCs10 = [NaN,1,1,np,1]; 
    L11 = 'max esc'; xNdCs11 = [NaN,nK,nR,1,nc];%  
end
%m==0:
xNdCs100 = [NaN,mPt(2),mPt(3),np,1]; %Min for rho0
xNdCs110 = [NaN,mPt(2),mPt(3),1,nc]; %Max for rho0


% L1  = 'all mid'; dta1  = N1v.*pFun(:,mPt(2),mPt(3),mPt(4),mPt(5));  % plot data: escapement
% L2  = 'K_{lo}';  dta2  = N1v.*pFun(:,1     ,mPt(3),mPt(4),mPt(5));  % plot data: escapement
% L3  = 'K_{hi}';  dta3  = N1v.*pFun(:,nK    ,mPt(3),mPt(4),mPt(5));  % plot data: escapement
% L4  = 'R_{lo}';  dta4  = N1v.*pFun(:,mPt(2),1     ,mPt(4),mPt(5));  % plot data: escapement
% L5  = 'R_{hi}';  dta5  = N1v.*pFun(:,mPt(2),nR    ,mPt(4),mPt(5));  % plot data: escapement
% L6  = 'p_{lo}';  dta6  = N1v.*pFun(:,mPt(2),mPt(3),1     ,mPt(5));  % plot data: escapement
% L7  = 'p_{hi}';  dta7  = N1v.*pFun(:,mPt(2),mPt(3),np    ,mPt(5));  % plot data: escapement
% L8  = 'c_{lo}';  dta8  = N1v.*pFun(:,mPt(2),mPt(3),mPt(4),1     );  % plot data: escapement
% L9  = 'c_{hi}';  dta9  = N1v.*pFun(:,mPt(2),mPt(3),mPt(4),nc    );  % plot data: escapement
% L10 = 'all bad'; dta10 = N1v.*pFun(:,1,1,1,nc);  
% L11 = 'all good';dta11 = N1v.*pFun(:,nK,nR,np,1); 
lab = {L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,'45^o line'};
%plot(N1v,dta1,'.-'); 
%y1 = plot(N1v,[dta1 dta2 dta3 dta4 dta5,dta6,dta7,dta8,dta9,dta10,dta11],'.-'); 

xNdCs = [xNdCs1; xNdCs2; xNdCs3; xNdCs4; xNdCs5; xNdCs6; xNdCs7; xNdCs8; xNdCs9; xNdCs10; xNdCs11; xNdCs100; xNdCs110]; 
[dtaEscRaw, dtaEscShr, dtaEscRaw0, dtaEscShr0] = deal(NaN*ones(size(xNdCs,1),nN1));
NvecArray = NaN*ones(size(xNdCs,1),nN1);
for j = 1:size(xNdCs,1)
    zKi = xNdCs(j,2); zK = MFoc.Kv(zKi);
    zRi = xNdCs(j,3); zR = MFoc.Rv(zRi); 
    zpi = xNdCs(j,4); zp = MFoc.pv(zpi); 
    zci = xNdCs(j,5); zc = MFoc.cv(zci); 

    dtaEscRaw(j,:)  = N1v.*MFoc.pFun(:,zKi,zRi,zpi,zci); 
    dtaEscRaw0(j,:) = N1v.*M0.pFun(:,zKi,zRi,zpi,zci); % M = 0 case
    NvecArray(j,:) = N1v; 

    dtaEscShr(j,:)  = MFoc.pFun(:,zKi,zRi,zpi,zci); 
    dtaEscShr0(j,:) = M0.pFun(:,zKi,zRi,zpi,zci); 
    isDec1st = 1 + find(diff(NvecArray(j,:))<0,1); % Find first diff that's negative to find where N vector dec.  
    NvecArray(j,isDec1st:end) = NaN;     
end

if 0 %Turn on if producing figure 1
    %% Escapement share and level figs over stock for each shock extreme and midpoint.
    fig=1; figure(fig); clf;  figh=5; figw=12; %figh=3.75; figw=7; %fig width and height
        figtitle = ['policy_funs_m' num2str(m*100)]; 
        set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
        set(gcf,'Color','w')


    col='kbbrrggmmcccc'; 
    sty= {'*-','.:','.--','.:','.--','.:','.--','.:','.--','.:','.--','.:','.--'};

    for i=1:2
        subplot(1,2,i)
    %     if     i==1; y1 = plot(N1v,dtaEscShr,'.-');
    %     elseif i==2; y1 = plot(N1v,dtaEscRaw,'.-');
        if     i==1 %y1 = plot(NvecArray,dtaEscShr,'.-');
            for j = 1:size(xNdCs,1)
                plot(NvecArray(j,:),dtaEscShr(j,:),[col(j) sty{j}]); hold on
            end
        elseif i==2 %y1 = plot(NvecArray,dtaEscRaw,'.-');
            for j = 1:size(xNdCs,1)
                plot(NvecArray(j,:),dtaEscRaw(j,:),[col(j) sty{j}]); hold on
            end
            legend(lab,'Location','Best')
        end
        temp=gca; set(temp.Children,'LineWidth',1.5)
        %set(y1,'LineWidth',1)
        xlabel('stock'); ylabel('escapement');
        %xlim([0,K]);
        grid on
    end
    %Add 45 degree line
    yL = ylim;
    plot([0 yL(2)],[0 yL(2)],':k')          

    %print([figdest_soln '\' num2str(fig) figtitle],'-dpng','-r0')
    %         print([figdest_paper '\' num2str(fig) figtitle],'-depsc','-painters')
end

if 0
    %% Escapement level figs over stock for each shock extreme and midpoint; m0 versus mOther
    fig=11; figure(fig); clf;  figh=4.5; figw=11.5; %figh=3.75; figw=7; %fig width and height
        figtitle = ['policy_funs_m0vsM' num2str(m*100)]; 
        figtitle = [figtitle '_' systmodel '_' npaltCase];
        set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
        set(gcf,'Color','w')

    col='kbbccggmmrrrr'; 
    %sty= {'*-','.:','.--','.:','.--','.:','.--','.:','.--','.:','.--','.:','.--'};  %good for color but not black and white
    sty= {'*-','o:','o--','x:','x--',':','--','+:','+--','^:','^--','^:','^--'};

    % First time plotting turn off constEsc indicator and verify that escapement policy functions are indeed linear. 
    constEsc=1; % Turn on for constant escapement policy so that horizontal lines hit y=x line instead of angling across discrete points.
    
    for i=1:2
        subplot(1,2,i)
        if i==1 
            %plotrows = [1:9 12:13]; %all
            plotrows0 = [1 6:9 12:13]; labSet0 = [1 6:12]; labSet=labSet0; %skip 2:5 (K and R), no variation over these variables.
            for j = plotrows0%1:size(xNdCs,1)
                Xplt=NvecArray(j,:); Yplt=dtaEscRaw0(j,:);  
                if constEsc; ce = Yplt(end); Xplt =[Xplt(Xplt<ce) ce:10:max(Xplt)]; Yplt =[Yplt(Xplt<ce) ce+0*(ce:10:max(Xplt))]; end
                plot(Xplt,Yplt,[col(j) sty{j}],'LineWidth',1.5); hold on
            end
            title('\rho = 0')
        elseif i==2
            plotrows = [1:11]; labSetm = [1:12]; labSet=labSetm; 
            for j = plotrows%1:size(xNdCs,1)
                Xplt=NvecArray(j,:); Yplt=dtaEscRaw(j,:);
                if constEsc; ce = Yplt(end); Xplt =[Xplt(Xplt<ce) ce:10:max(Xplt)]; Yplt =[Yplt(Xplt<ce) ce+0*(ce:10:max(Xplt))]; end
                plot(Xplt,Yplt,[col(j) sty{j}],'LineWidth',1.5); hold on
            end
            title(['\rho = ' num2str(m)])
        end
        %temp=gca; set(temp.Children,'LineWidth',1.5)
        %set(y1,'LineWidth',1)
        xlabel('post-shock stock, {\it x}'); ylabel('escapement');
        %xlim([0,K]);
        grid on
        lim = 100; xlim([0,lim]); ylim([0,lim])
        %Add 45 degree line
        yL = ylim;
        plot([0 yL(2)],[0 yL(2)],':k')   
        legend(lab(labSet),'Location','Best')
    end 
    if 1 % overwrites policy function of stock version with 1 bar showing constant escapement
        %%
        constEscLev0 = dtaEscRaw0(plotrows0,end); % get constant escapement levels from escapement at largest N
        lab(labSet0)
        constEscLev  = dtaEscRaw(plotrows,end); 
        lab(labSetm)
        constEscLevBoth = [[constEscLev0(1); NaN*ones(4,1); constEscLev0(2:end)] constEscLev]; % Match up CE levels.
        %        subplot(1,2,2); hold off
        fig=11; figure(fig); clf;  figh=3.75; figw=5; %figh=3.75; figw=7; %fig width and height
        set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
        set(gcf,'Color','w')
        ord2plot = [1 10 11 6:9 2:5]; 
        %x4bars = [1 2.25 2.75 4:11];
        b=bar(constEscLevBoth(ord2plot,:));
        b(1).FaceColor = 'black';
        b(2).FaceColor = 'cyan';
        xticklabels(lab(labSetm(ord2plot)))
        xtickangle(45); grid on
        ylabel('constant escapement level')
        legend('\rho = 0','\rho = 0.95','Location','Best')
        figsuffix='bar'; 
        if strcmp(systmodel,'base');
            ylim([0,100]); ttt=text(3.45,100,'\leftarrow','FontSize',16); set(ttt,'Rotation',310); text(3.75,92,num2str(round(constEscLevBoth(11,2))))
        end
    else
        figsuffix=[]; 
    end
    disp(['Figure for case: ' casename])
    disp(['Figure file name: ' num2str(fig) figtitle])
    if 0
       print([figloc num2str(fig) figtitle figsuffix],'-dpng','-r0')
       print([figloc num2str(fig) figtitle figsuffix],'-depsc','-painters')
       print([figloc num2str(fig) figtitle figsuffix],'-dpdf')%,'-painters')
    end
end


if 0
    %% figs 2:5
    eval(['M = M' num2str(100*m) ';'])
    focVar = {'N','K','R;K0','P','C'};
    % Set focal state variable: e.g. K, R, etc.
    for nsj = 2:5
        if     nsj==2; ns = nK; sv = Kv; % focal variable, index of focal variable
        elseif nsj==3; ns = nR; sv = Rv; 
        elseif nsj==4; ns = np; sv = pv; 
        elseif nsj==5; ns = nc; sv = cv;
        end
        figure(nsj); clf

        ttl = ['Focal var: ' focVar{nsj}];  %title

        % Set the nodes to plot: mid-point for all except focal variable.
        xNdCs = NaN*ones(ns,nx);
        for j = 2:nx
            xNdCs(:,j) = mPt(j); %set to mid-point
        end
        xNdCs(:,nsj) = 1:ns;     

        [dtaEscRaw, dtaEscShr, dtaVfun] = deal(NaN*ones(size(xNdCs,1),nN1));
        NvecArray = NaN*ones(size(xNdCs,1),nN1);
        for j = 1:size(xNdCs,1)
            zKi = xNdCs(j,2); zK = MFoc.Kv(zKi);
            zRi = xNdCs(j,3); zR = MFoc.Rv(zRi); 
            zpi = xNdCs(j,4); zp = MFoc.pv(zpi); 
            zci = xNdCs(j,5); zc = MFoc.cv(zci); 
            if 0 %old way: policy fun is pre-growth
                dtaEscRaw(j,:) = Gf(zK,zR,N1v).*M.pFun(:,zKi,zRi,zpi,zci); 
                NvecArray(j,:) = Gf(zK,zR,N1v); 
            elseif 1
                dtaEscRaw(j,:) = N1v.*M.pFun(:,zKi,zRi,zpi,zci); 
                NvecArray(j,:) = N1v; 
            end                
            dtaEscShr(j,:) = M.pFun(:,zKi,zRi,zpi,zci); 
            dtaVfun(j,:)   = vFun(:,zKi,zRi,zpi,zci); 
            isDec1st = 1 + find(diff(NvecArray(j,:))<0,1); % Find first diff that's negative to find where N vector dec.  
            NvecArray(j,isDec1st:end) = NaN;
        end

        % for use later.
        if nsj==2; N_KN = NvecArray; Esh_KN = dtaEscShr; end

        subpVar = {'escapement share','escapement','V','V (various N)','N_{t+1}','profit'};
        xlabVar = {'stock','stock','stock',focVar{nsj},'stock','stock'};
        for i=1:6
            subplot(2,3,i)
            if     i==1; %y1 = plot(N1v,dtaEscShr,'.-b');
                for j = 1:size(xNdCs,1)
                    plot(NvecArray(j,:),dtaEscShr(j,:),'.-b'); hold on
                end
                title(ttl);
                ph = get(gca,'Children');
                h=legend([ph(1) ph(end)],{'high','low'},'Location','Best'); %note children are ordered oddly
                %set(get(h,'title'),'string',legtitle);
            elseif i==2 %y1 = plot(N1v,dtaEscRaw,'.-b');
                for j = 1:size(xNdCs,1)
                    plot(NvecArray(j,:),dtaEscRaw(j,:),'.-b'); hold on
                end
            elseif i==3
                plot(N1v, dtaVfun,'.-b'); hold on
            elseif i==4
                plot(sv, dtaVfun','.-b')
            elseif i==5  % depending on focal variable, stock dynamics
                for jj=1:length(sv)
                    if      nsj==2; Kvc = sv(jj);     Rvc = Rv(mPt(3)); 
                    elseif  nsj==3; Kvc = Kv(mPt(2)); Rvc =sv(jj);
                    else            Kvc = Kv(mPt(2)); Rvc = Rv(mPt(3)); 
                    end
                    hp = ezplot(@(N) Gf(Kvc,Rvc,N),[0,150]); hold on
                    set(hp,'Color','b')
                end
                %ylabel('N_{t+1}'); 
                grid on           
            elseif i==6  % depending on focal variable, profit, assuming midpoint for all others.
                for jj=1:length(sv)
                    if      nsj==4; pvc = sv(jj);     cvc = cv(mPt(5)); 
                    elseif  nsj==5; pvc = pv(mPt(4)); cvc = sv(jj);
                    else            pvc = pv(mPt(4)); cvc = cv(mPt(5)); 
                    end
    %                 Ac = .8; 
    %                 hp = ezplot(@(N) PI_netprof_multTCorrShk(pvc,cvc,N,Ac),[0,150]); hold on
    %                set(hp,'Color','b')
                    Nvc = NvecArray(mPt(nsj),:); 
                    Avc = dtaEscShr(mPt(nsj),:); 
                    plot(Nvc,PI_netprof_multTCorrShk(pvc,cvc,Nvc,Avc),'-b'); hold on
                end
                %ylabel(['profit given A = ' num2str(Ac)]); 
                grid on                        
            end

            temp=gca; 
            if i~=4
                for j = 1:ns;  set(temp.Children(j),'LineWidth',.3+j*.2); end
            else
                for j = 1:nN1;  set(temp.Children(j),'LineWidth',.3+(nN1-j)*.1); end
            end        
            ylabel(subpVar{i}); 
            xlabel(xlabVar{i}); 
            % Figure additions
            if     i==3;             plot(N1v([1:2:19 20]),dtaVfun(:,[1:2:19 20]),'*r'); %nodes
            elseif i==5;             
                ezplot(@(N) N, [0,150]); %90 degree line 
                for j = 1:size(xNdCs,1)
                    plot(dtaEscRaw(j,:),NvecArray(j,:),'.-c'); hold on
                end
                temp=gca; for j = 1:ns;  set(temp.Children(j),'LineWidth',.3+j*.2); end
            end
            %xlim([0,K]);
            grid on
        end
    end
end


%%
doFine = 1;   % Plot finer resolution fig -- takes a bit more time.
% Grid size of finer discretization.
gs = 200; nanPixSz = 1.25; % Publish quality
%gs = 50;  nanPixSz = 5;

SS = 1;  % State variable combo case (e.g. K&R, p&c, etc) -- see next if statement
override2PlotM0 = 0; % Highjack to plot M0 case for ZpZc only.
cbarOveride = 0;
if SS==1   %K & R
    ss = 'ZkZr'; 
    S1  = '\it z^K'; S2 = '\it z^R'; 
    nS1 = nK;    nS2 = nR; 
    S1v = Kv;    S2v = Rv;
    cbarOveride = 1;
    cbarLim=[.5 1]; % min and max of colorbar, set manually to make same across subplots.      
    casecheck = [systmodel '_' npaltCase];
    if     strcmp('base_ArdMat52',casecheck);           cbarLim=[.3 1];
    elseif strcmp('critdep_ArdMat52',casecheck);        cbarLim=[.35 1];
    elseif strcmp('base_ArdMat52_CMC',casecheck);       cbarLim=[.1 1];
    elseif strcmp('critdep_ArdMat52_CMC',casecheck);    cbarLim=[.25 1];
    end
elseif SS==2  % p & c
    ss = 'ZpZc'; 
    S1  = '\it z^p'; S2 = '\it z^c'; 
    nS1 = np;    nS2 = nc; 
    S1v = pv;    S2v = cv;
    if ~override2PlotM0
        if      doConstMCHarv==1; cbarLim=[.45 1]; %M95, base, CMC-indep
        elseif  doConstMCHarv==0; cbarLim=[.32 1]; %M95, base, dep
        end
        cbarOveride = 1;
    elseif override2PlotM0
        if      doConstMCHarv==1; cbarLim=[.2 1]; %M0, base, CMC-indep
        elseif  doConstMCHarv==0; cbarLim=[.2 1]; %M0, base, dep
        end
        cbarOveride = 1;
    end
elseif SS==3   %K & c
    ss = 'ZkZc'; 
    S1  = '\it z^K'; S2 = '\it z^c'; 
    nS1 = nK;    nS2 = nc; 
    S1v = Kv;    S2v = cv;    
elseif SS==4   %R & c
    ss = 'ZrZc'; 
    S1  = '\it z^R'; S2 = '\it z^c'; 
    nS1 = nR;    nS2 = nc; 
    S1v = Rv;    S2v = cv;    
elseif SS==5   %K & p
    ss = 'ZkZp'; 
    S1  = '\it z^K'; S2 = '\it z^p'; 
    nS1 = nK;    nS2 = np; 
    S1v = Kv;    S2v = pv;    
elseif SS==6   %R & p
    ss = 'ZrZp'; 
    S1  = '\it z^R'; S2 = '\it z^p'; 
    nS1 = nR;    nS2 = np; 
    S1v = Rv;    S2v = pv;    
end

%set(findall(gcf,'type','axes'),'FontSize',10);%,'FontName','Fira Sans')
%set(findall(gcf,'type','text'),'FontSize',14,'FontWeight','Normal');
           
fig=6; fh=figure(fig); clf;  figh=6; figw=8; %figh=3.75; figw=7; %fig width and height
    figtitle     = {['Esc share,'] [' \rho = ' num2str(m)]}; 
    figSaveTitle = ['EscShare' ss 'SerrCorrM' num2str(100*m)]; 
    figSaveTitle = [figSaveTitle '_' systmodel '_' npaltCase];
    set(gcf,'Units','inches','Position',[1,0,figw,figh]); %[left, bottom, width, height]
    set(gcf,'Color','w')
Ncase = [40,60,80,100]; 

for j=1:4
    for zS1i=1:nS1
    for zS2i=1:nS2
        if SS==1
            zKi=zS1i; zRi=zS2i; zPi = mPt(4); zCi=mPt(5); 
        elseif SS==2
            zKi=mPt(2); zRi=mPt(3); zPi = zS1i; zCi=zS2i;  %display('base plot case')
            %zKi=9; zRi=9; zPi = zS1i; zCi=zS2i;  display('alt case: K and R are high')
        elseif SS==3
            zKi=zS1i; zRi=mPt(3); zPi = mPt(4); zCi=zS2i;  
        elseif SS==4
            zKi=mPt(2); zRi=zS1i; zPi = mPt(4); zCi=zS2i; 
        elseif SS==5
            zKi=zS1i; zRi=mPt(3); zPi = zS2i;  zCi=mPt(5);  
        elseif SS==6
            zKi=mPt(2); zRi=zS1i; zPi = zS2i;  zCi=mPt(5);  
        end
        if ~override2PlotM0
            Ei = MFoc.pFun(:,zKi,zRi,zPi,zCi); 
            if 0
                Ni = Gf(MFoc.Kv(zKi),MFoc.Rv(zRi),N1v); 
            elseif 1 % pol is fun of post-growth.
                Ni = N1v; 
            end   
        elseif override2PlotM0 %override focal M case to plot M=0 case instead.
            Ei = M0.pFun(:,zKi,zRi,zPi,zCi); 
            if 0  %old version...policy if function of pre-growth
                Ni = Gf(M0.Kv(zKi),M0.Rv(zRi),N1v); 
            elseif 1 % pol is fun of post-growth.
                Ni = N1v; 
            end            
            figtitle{2}=[' \rho = ' num2str(0)];
            %figSaveTitle = ['EscShare' ss 'SerrCorrM0Ver' ver0]; 
            figSaveTitle = ['EscShare' ss 'SerrCorrM0_' systmodel '_' npaltCase];
        end
        isDec1st = 1 + find(diff(Ni)<0,1); % Find first diff that's negative to find where N vector dec.  
        Ni(isDec1st:end) = NaN;
        Ei = Ei(~isnan(Ni)); Ni = Ni(~isnan(Ni));
        if abs(Ncase(j)-max(Ni))<1 % if Ncase(j) is beyond range but just barely:
            Esh(zS1i,zS2i) = interp1(Ni, Ei, Ncase(j),'pchip'); %Allow extrapolation
        else
            Esh(zS1i,zS2i) = interp1(Ni, Ei, Ncase(j),'pchip',NaN); %NaN is the extrapvalue
        end
    end
    end
    
    % Get the M = 0 value for comparison, all shock levels at midpoints:
        Ei = M0.pFun(:,mPt(2),mPt(3),mPt(4),mPt(5)); 
        if 0 % old version
            Ni = Gf(M0.Kv(mPt(2)),M0.Rv(mPt(3)),N1v); 
        elseif 1 % pol is fun of post-growth.
            Ni = N1v; 
        end   
        isDec1st = 1 + find(diff(Ni)<0,1); % Find first diff that's negative to find where N vector dec.  
        Ni(isDec1st:end) = NaN;
        Ei = Ei(~isnan(Ni)); Ni = Ni(~isnan(Ni));
        E0 = interp1(Ni, Ei, Ncase(j),'pchip',NaN);   
        if abs(Ncase(j)-max(Ni))<1 % if Ncase(j) is beyond range but just barely:
            E0 = interp1(Ni, Ei, Ncase(j),'pchip'); %Allow extrapolation
        else
            E0 = interp1(Ni, Ei, Ncase(j),'pchip',NaN); %NaN is the extrapvalue
        end
        [M0Ki,M0Ri] = find(abs(Esh-E0) == min(abs(Esh(:)-E0))); %indices in Esh where the M>0 policy is equal to the M=0 policy
        
        
    subplot(2,2,j)
%    fhj = heatmap(cellstr(string(Rv))',cellstr(string(Kv))',Esh)

    if doFine %interpolate for finer density
        [S1vBs,   S2vBase] = ndgrid(S1v,S1v); %create matrix of state variables using existing discretization.
        S1vPlt = linspace(min(S1v),max(S1v),gs); S2vPlt = linspace(min(S2v),max(S2v), gs); 
        [S1vPltMat, S2vPltMat] = ndgrid(S1vPlt, S2vPlt);
        Erz    = sum(isnan(Esh),2)==0; 
        EshPlt = interpn(S1vBs(Erz,:), S2vBase(Erz,:), Esh(Erz,:), S1vPltMat, S2vPltMat,'spline',NaN); 
        EshPlt(EshPlt<0) = 0; EshPlt(EshPlt>1) = 1; 
    else
        S1vPlt = S1v; S2vPlt = S2v; EshPlt = Esh;
    end
    image(S2vPlt,S1vPlt,EshPlt,'CDataMapping','scaled'); % 'CDataMapping','scaled'--> scales colors to full range of colormap instead of narrower subset.
    if j>=1;  colorbar; end % can restrict to only 1 copy...but scaling of figs suffers. 
    ax = gca;  % 
    cbarLimj = ax.CLim; % upon first plot find out what max range for colorbar is and make uniform.
    if cbarOveride
        if (SS==1 && m==.95) || override2PlotM0 % Make bars uniform--wide range that is similar
            if min(cbarLimj)<cbarLim(1) || max(cbarLimj)>cbarLim(2); error('Color bar range is too small'); end 
%         elseif SS==2 || m==.5 %Use floor and ceil to get regular bounds (to second decimal) for colorbar
%             cbarLim(1) = floor(100*cbarLimj(1))/100;
%             cbarLim(2) = ceil(100*cbarLimj(2))/100; 
        end
        ax.CLim = cbarLim;
    end
    if SS==1 %Over-paint NaN cells--only applies when variables effect N (i.e. for K/R). 
        hold on
        [nanpy, nanpx] = find(isnan(EshPlt));
        col = .75*[1 1 1];
        for jj=1:length(nanpx)
            plot(S2vPlt(nanpx(jj)),S1vPlt(nanpy(jj)),'sq','MarkerEdgeColor',col,'MarkerFaceColor',col,'MarkerSize',nanPixSz);%21)
        end
    end
 display('x/y tick mod turned off:')
%    xticks(S2v(1:2:end));  yticks(S1v(1:2:end))
    xlabel(S2);       ylabel(S1); % I don't think subscripts work in heatmap
    if SS==1; ttlAdd = [', {\it A}^*_{0} = ' num2str(round(E0*100)/100)]; else ttlAdd = []; end  % M0 escapement fixed only for KR case, not pc case
    title(['{\it  x} = ' num2str(Ncase(j)) ttlAdd])
    %text(Rv(M0Ri)-.08,Kv(M0Ki),num2str(round(E0*100)/100))
    if 0 && SS==1
        for zKi=1:nK
        for zRi=1:nR
            if Esh(zKi,zRi)>E0; plot(Rv(zRi),Kv(zKi),'+','Color',.25*[1 1 1]); end
        end
        end
    end
    if SS==1 && strcmp(systmodel,'base') %Plots the white line dividing above and below M=0 solution.
        % only for zk/zr since M0 policy non-constant for zp/zc
        notNaN = sum(isnan(EshPlt),2)==0; 
        [~,colE0]=min(abs(EshPlt - E0),[],2); % Get column numbers where value is closest to E0.
        notClose = min(abs(EshPlt - E0),[],2)>0.01; % Use NaN to omit rows where there isn't a sufficiently close value. 
        colE0(notClose) = NaN; % 
        notNaN(notClose) = 0; 
        %scatter(S2vPlt(colE0(notNaN)),S1vPlt(notNaN),'.w')
        if ~(E0>=.98)
            plot(S2vPlt(colE0(notNaN)),S1vPlt(notNaN),'--w','LineWidth',2)
        end
%         if j==1  %manually fill gap:
%             temp2 = S2vPlt(colE0(notNaN)); temp1 = S1vPlt(notNaN);
%             plot([.5 temp2(1)],[temp1(1), temp1(1)],'-w','LineWidth',2)
%         end
    end
    grid on
end
%quick and dirty sup title:
if 0
    fh.NextPlot = 'add'; a = axes; ht = title(figtitle); a.Visible = 'off'; ht.Visible = 'on';
    disp(['Figure ' num2str(fig) ' shows optimal escapement given \rho = ' num2str(m) ' and the given stock in each subplot.  Optimal escapement in the no serial correlation model (\rho = 0) is given in subtitle and + symbols indicate where escapement is greater than in no ser corr model'])
end

disp(['Figure for case: ' casename])
disp(['Figure file name: ' num2str(fig) figSaveTitle])
if 0
    print([figloc num2str(fig) figSaveTitle],'-dpng','-r0')
    print([figloc num2str(fig) figSaveTitle],'-depsc2')%,'-painters')
    print([figloc num2str(fig) figSaveTitle],'-dpdf')%,'-painters')
end



