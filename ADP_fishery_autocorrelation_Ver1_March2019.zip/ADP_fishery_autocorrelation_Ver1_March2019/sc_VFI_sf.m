% sc_VFI_sf
% Solve simple single shock model
% Parallelization: uses parfor-loops.  But this is only about 10% faster than regular for-loops.

% Control VFI tracking figure, on (1) or off (0)
do_tf = 0; 

%% Set VFI options

% Set solution tolerance (NOTE: in percentage (not share) terms)
switch systmodel
    case 'base';    VFI_stoptol = 0.0001; % Need a tolerance of at least 0.001% in base case to arrive at a value function estimate that doesn' continue to climb appreciably (from below).
    case 'critdep'; VFI_stoptol = 0.0001; % 
end

% VFI_stoptol = 0.01; display('DEBUGGING STOP TOL')

interp_meth = 'pchip';  % preferred interpolation method -- does not overshoot 

% m = z*n: post shock stock; A: escapement share 
% specify negative of payoff function (to min); decision maker will optimize post shock so shock in function here set to 1.   
negpayoff_fun = @(A,m,Vbart) -PI_netprof(1,m,A) - delta*interp1(N1v,Vbart,Gf(m*A),interp_meth); 

% pre-allocate VFI vectors
[action, v_m, flag, Vnew] = deal(NaN*zeros(state_n,1)); 

maxdevperc = VFI_stoptol*2;  % initialize vfi deviation metric to some number > VFI_stoptol
Vbart      = Vbar;           % Vbart is "current" estimate of value function.
iter       = 1;              % iteration counter
maxdp_hist = NaN*ones(1000,1);

% Establish tracking figure
from_SW_crnr = 3; 
if do_tf; fig=77; figure(fig); clf; figw=10; figh=8; set(gcf,'Units','inches','Position',[from_SW_crnr, from_SW_crnr, figw, figh]); set(gcf,'Color','w'); end

%% Run VFI
tic
while maxdevperc > VFI_stoptol 
    % single shock process
    % Order of events: shock--> harvest --> growth.
    % optimize given m (post-shock stock)
    parfor i_m = 1:state_n  %across all post-shock stock levels...
        m = N1v(i_m); % N1v is the pre-shock stock vector, but it's being used here to cycle through possible values of m = z*N.
        % expected value of the maximized payoff given manager KNOWS the post-shock stock.
        [action(i_m), v_m(i_m), flag(i_m)] = fmincon(@(A)negpayoff_fun(A,m,Vbart),0,[],[],[],[],0,1,[],optimoptions('fmincon','Display','off')); %fminbnd(@(A)negpayoff_fun(A,m,Vbart),0,1); %
    end
    v_m = -v_m; %change negpayoff to payoff  
    % Next is an unusual step:
    % translate value of post shock stock to preshock stock: v_m(m) --> V(N)
    V_N_zt = @(N,zt) pdf(PDF_shock,zt).*interp1(N1v,v_m,N*zt,interp_meth); % specify integrand: value function of pre-shock stock given value of post-shock stock
    parfor i_n = 1:state_n   %for each pre-shock stock level, N
        Vnew(i_n) = integral(@(zt) V_N_zt(N1v(i_n),zt) , minz, maxz);  % expected value of starting stock level N, integrating across pdf of shocks.       
    end
            
    Vnew(ext)=0;      % ensure that value at extinct stock is exactly zero
    Vnew(Vnew<0) = 0; % ensure no negative V values.
    
    maxdevperc       = max(abs(Vnew-Vbart)./Vbart)*100; % vfi deviation metric
    maxdp_hist(iter) = maxdevperc; 
    Vbart            = Vnew;                           % update estimate of value function.
    iter             = iter + 1;                       % iteration counter
    
    if do_tf % tracking figure
        disp(['Max %-diff: ' num2str(maxdevperc)])
        figure(fig); 
        if strcmp(systmodel,'base'); yub=600; elseif strcmp(systmodel,'critdep'); yub = 1000; end
        subplot(2,2,1); plot(N1v,v_m,'.-');           ylabel('v_m(z*N)');        xlabel('m = z*N'); hold on; grid on; %ylim([0,yub]);
        subplot(2,2,2); plot(N1v,action.*N1v,'.-');   ylabel('opt. escapement'); xlabel('m = z*N'); hold on; grid on
        plot(Gf(N1v(N1v<=K)),N1v(N1v<=K)); % Where this line intersects with escapement will be approx steady state area (esc on vertical axis, pop before harvest on horiz. axis).
%        subplot(2,2,2); plot(N1v,a_m_P.*repmat(N1v,[1,n_P]),'.-');   ylabel('opt. escapement'); xlabel('m = z*N'); hold on; grid on
        subplot(2,2,3); plot(N1v,Vbart,'.-');         ylabel('V(N)');            xlabel('N');       hold on; grid on; %ylim([0,yub]);
        subplot(2,2,4); plot(1:iter,maxdp_hist(1:iter),'.-'); ylabel('max dev % in V');xlabel('iteration'); grid on
        drawnow; 
    end
end
toc
%%
Vbar = Vbart; 

fig=78; figure(fig); clf; figw=10; figh=8; set(gcf,'Units','inches','Position',[from_SW_crnr,from_SW_crnr, figw, figh]);  set(gcf,'Color','w')
        subplot(2,2,1); plot(N1v,v_m,'.-');             ylabel('v_m(z*N)');        xlabel('m = z*N'); hold on; ylim([0,600]); grid on
        subplot(2,2,2); plot(N1v,action(:).*N1v,'.-');  ylabel('opt. escapement'); xlabel('m = z*N'); hold on; grid on
                        plot(Gf(N1v(N1v<=K)),N1v(N1v<=K)); % Where this line intersects with escapement will be approx steady state area.
                        legend('opt. esc. fun.','inverse growth function')
%        subplot(2,2,2); plot(N1v,a_m_P.*repmat(N1v,[1,n_P]),'.-');  ylabel('opt. escapement'); xlabel('m = z*N'); hold on; grid on
        subplot(2,2,3); plot(N1v,Vbart,'.-');         ylabel('V(N)');            xlabel('N');       hold on; ylim([0,600]); grid on
        subplot(2,2,4); plot(N1v,(1-action(:)).*N1v,'.-');  ylabel('opt. harvest'); xlabel('m = z*N'); hold on; grid on
if 0
    %Look at harvest, revenue and cost given policy:        
    %stock; esc share;                 harvest;        revenue;          cost;                  cost/profit ratio;           profit
    [N1v    action  (1-action).*N1v.*[ones(size(N1v)) p*ones(size(N1v)) cparm.*log(1./action) ] (cparm.*log(1./action))/p    PI_netprof(1,N1v,action) ]
    disp('stock; esc share; harvest; revenue; cost; profit/cost ratio; profit')
    %det steady state is where: [N1v == G_logist_std(N1v.*action)]
    [N1v G_logist_std(N1v.*action)]
end
% Save results
if 0
    filename = [saveloc 'solutions\soln_' casename];
    save(filename)        
end       

 

















