%% sc_analysis_of_solution_sf: generate policy function; run sims for performance comparison; generate policy function figs
% For multCorrShk model only

%% Setup: warnings, computer name
clear
close all
warning('off','MATLAB:DELETE:Permission')         % we call for deletion of files that might not exist, to ensure non-use of old files.
warning('off','MATLAB:dispatcher:nameConflict')   % when adding path for patchplot
warning('off','MATLAB:mir_warning_maybe_uninitialized_temporary');


%% Setup cases: included shocks, growth model, harvest cost, m (level of autocorrelation)
% Case order: {noprofshock, nobiolshock, onlyKshock, onlyRshock, onlyPshock, onlyCshock}
shockCase{1} = {0,0,0,0,0,0}; scNm{1} = 'All included';    scFileNm{1} = [];
shockCase{2} = {1,0,0,0,0,0}; scNm{2} = 'noprof';          scFileNm{2} = '_noprofshock';
shockCase{3} = {1,0,1,0,0,0}; scNm{3} = 'noprof, only K';  scFileNm{3} = '_noprofshock_onlyK';
shockCase{4} = {1,0,0,1,0,0}; scNm{4} = 'noprof, only R';  scFileNm{4} = '_noprofshock_onlyR';
shockCase{5} = {0,1,0,0,0,0}; scNm{5} = 'nobiol';          scFileNm{5} = '_nobiolshock';
shockCase{6} = {0,1,0,0,1,0}; scNm{6} = 'nobiol, only P';  scFileNm{6} = '_nobiolshock_onlyP';
shockCase{7} = {0,1,0,0,0,1}; scNm{7} = 'nobiol, only C';  scFileNm{7} = '_nobiolshock_onlyC';

% growth model
if     1;   systmodel = 'base'    ; %base model
elseif 0;   systmodel = 'critdep'; %critical depensation model
elseif 0;   systmodel = 'rick'; %
end

% Specify harvest cost function
if 0
    doConstMCHarv = 0; % default: MC decreasing in stock level
    npaltCase='ArdMat52';
else
    doConstMCHarv = 1; 
    npaltCase='ArdMat52_CMC';
end
npaltCase4M0=npaltCase; %for M=0 comparison

% Specify value function solution version to use
[ver0, ver95]   = deal('17');
[ver50, ver100] = deal('notAvail'); % cases not completed

%% Specify which procedures to run: generate policy function; run simulations
if 0;       do_policy_fun_cal = 1; do_sims = 0;                                     % First time: calc policy functions
elseif 0;   do_policy_fun_cal = 0; do_sims = 1; useSavedSims  = 0; saveSims = 1;    % After policy functions are done, run simulations
elseif 1;   do_policy_fun_cal = 0; do_sims = 1; useSavedSims  = 1;                  % After sims done just load.    
end

% Set autocorrelation case(s) 
if   do_sims; mvec = [.95]; % Skip m=0 for sims since m=0 automatically completed when running any case with m>0
else          mvec = [0 .95]; 
end 

if 0 % Turn this on just for m=0 heatmap plots:
     do_policy_fun_cal = 0; do_sims = 0; useSavedSims  = 0; mvec = 0;
end

%%
% Loop over shock and autocorrelation cases

dpf = 1; % set to 1 if using parallel computing on for loops.

for js = 1%:7 % jth shock case
    disp(['Shock case: ' scNm{js}])
for m  = mvec
    noprofshock = shockCase{js}{1}; onlyKshock = shockCase{js}{3}; onlyRshock = shockCase{js}{4}; 
    nobiolshock = shockCase{js}{2}; onlyPshock = shockCase{js}{5}; onlyCshock = shockCase{js}{6}; 
    var = scFileNm{js};  

    if     m==.95; verFoc = ver95;
    elseif m==0;   verFoc = ver0; 
    elseif m==.5;  verFoc = ver50;
    elseif m==1;   verFoc = ver100;
    end  
    % Get directory for value function solutions:
    startName   = ['soln_FDP_' systmodel];
    casename    = [startName verFoc '_multTCorrShk50_serCorr' num2str(m*100) var '_nonparam' npaltCase];
    casename100 = [startName ver100  '_multTCorrShk50_serCorr' num2str(100) var '_nonparam'];
    casename95  = [startName ver95  '_multTCorrShk50_serCorr' num2str(95) var '_nonparam' npaltCase];
    casename50  = [startName ver50  '_multTCorrShk50_serCorr' num2str(50) var '_nonparam'];
    casename0   = [startName ver0   '_multTCorrShk50_serCorr' num2str(0) var '_nonparam' npaltCase4M0];  %for M=0 comparison
    % Specify directories for output
    dest_soln   = [cd '\output\solutions\' casename];
    dest_soln100= [cd '\output\solutions\' casename100];
    dest_soln95 = [cd '\output\solutions\' casename95];
    dest_soln50 = [cd '\output\solutions\' casename50];
    dest_soln0  = [cd '\output\solutions\' casename0];
    % Load value function solution 
    solnmatfile = [dest_soln '\soln_matfile.mat'];  %mat file with solution.
    load(solnmatfile); 
    % Create directory for figures
    figdest_soln = [dest_soln '\figs']; mkdir(figdest_soln)   
    dest_soln = [cd '\output\solutions\soln_' casename]; %reinstate dest_soln--get's overwritten with loaded results.

    %% Get the policy function solution (PFS): if first time, calc from scratch, otherwise load.
    if ~do_policy_fun_cal
        % load policy function solutions already calculated
        if m==.95
            M95 = load([dest_soln95  '\soln_policyfun.mat'],'Policy_Fun','Policy_Fun_ind', 'casename','N1v','Kv','Rv','pv','cv','x_node');    
            M95.pFun = f_cleanPolicy(M95.Policy_Fun,x_node,Gf,nN1,nK,nR,np,nc); % Note: ultimately turned off cleaning inside the function.  open f_cleanPolicy
            M95.Vfit = Vfit; 
        elseif m==1
            M100 = load([dest_soln100  '\soln_policyfun.mat'],'Policy_Fun','Policy_Fun_ind', 'casename','N1v','Kv','Rv','pv','cv','x_node');    
            M100.pFun = f_cleanPolicy(M100.Policy_Fun,x_node,Gf,nN1,nK,nR,np,nc); 
        end
        M0  = load([dest_soln0 '\soln_policyfun.mat'],'Policy_Fun','Policy_Fun_ind', 'casename','N1v','Kv','Rv','pv','cv','x_node');
        getVfit0 = load([dest_soln0 '\soln_matfile.mat'],'Vfit','txfun');  %
        M0.Vfit = getVfit0.Vfit; 
        M0.txfun = getVfit0.txfun;
        M0.pFun  = f_cleanPolicy(M0.Policy_Fun,x_node,Gf,nN1,nK,nR,np,nc);
    elseif do_policy_fun_cal
        tic
        pfwid = 1;  % This is the parfor worker id--set arbitrarily here here to 1 (allows use of same code as solution)
        if ~dpf; disp('You have parallel turned off'); end
        sc_setparllwrks;   % Generate parallel pool with a particular number of workers depending on system
        sc_getpolfun_sf       % open sc_getpolfun_sf  
        save([dest_soln '\soln_policyfun.mat'],'Policy_Fun','Policy_Fun_ind', 'casename','N1v','Kv','Rv','pv','cv','x_node')  
        toc
        clear Policy_Fun Policy_Fun_ind
    end   
    
    %% Run sims
    if do_sims
        % Run sims and summarize results
        sc_runSerCorrSims; % open sc_runSerCorrSims
    end      
end
end
% If running policy calc or simulations, then end here.  
if do_policy_fun_cal == 1 || (do_sims && ~useSavedSims) ; return; end

% This will be for specific M case specified at top. 
vFun = reshape(Vbar,[nN1,nK,nR,np,nc]);  
eval(['MFoc = M' num2str(100*m) ';']); % Set focal case

%% Policy function figures
sc_PolFunFigs_multTCorrShk

