%% This code pulls up saved results to compare them.

%{
Each time you pull up results it will replace anything with the same name
in the workspace. Theoretically, this shouldn't be a problem--you want to
compare apples to apples anyway, which means you want all of the code you
are comparing to have been generated from identical parameters, with the
only difference being the solution method or the regression method (what we
are comparing across.)

Also, this code will (obviously) only work for models you've actually run.
%}

% Choose which of 'nonparam' and/or 'param' you would like to include in the comparison
%regmodelscompare = {'nonparam'};
regmodelscompare = {'param'};


% Choose which of 'quadratic' 'cubic' and/or 'quartic' you would liek to
% include in the comparison
poly_modelcompare = {'quartic'};% quadratic,'cubic' 'quartic'};

% Choose which of 'base' and 'critdep' you would like to compare across
% (choose 1 only)
%bio_model_c = 'base';
bio_model_c = 'critdep';


% Load VFI standard
filename = ['output/' 'soln_VFI_' bio_model_c];
load(filename)
Vbar_VFI = Vbar;
action_VFI = action;

% Compare on one figure
fig = 1; figure(fig); clf;
figw=13; figh=8;
set(gcf,'Units','inches','Position',[3, .4, figw, figh])  
set(gcf,'Color','w')
legendstring=[]; temp = []

%addl='soln_FDP_base_nonparam_wt_unif_nd_rep_1 -- 7-14 II - soln_FDP_base_nonparam_wt_unif_nd_rep_1 -- 7-14\'; 
addl=[];

for j = 1%:numel(poly_modelcompare)
    for i = 1:numel(regmodelscompare)
        for repFDP=1:10 %different FDP solutions for nonparam model
            regmodel2start = regmodelscompare{i};
            poly_model = poly_modelcompare{j};
            switch regmodel2start
                case 'param'
                    filename = [saveloc 'soln_FDP_' systmodel '_' regmodel2start '_' poly_model '_wt_equal_obs_rep_' num2str(repFDP)];
                    legendstring = [legendstring  '''' regmodel2start ' ' poly_model ''''  ','];
                case 'nonparam'
                    filename = [saveloc addl 'soln_FDP_' systmodel '_' regmodel2start '_wt_equal_obs_rep_' num2str(repFDP)];  %unif_nd
                    legendstring = [legendstring  '''' regmodel2start ' '''  ','];
            end
            Q=load(filename); 
            newnameVbar = ['Vbar' '_' num2str(i) num2str(j)];  %rework to handle repFDP
            str = [newnameVbar '= Q.Vbar;']; %rename Vbar once, so we hold on to it
            eval(str);
            str2 = ['plotvec =' newnameVbar ';']; %rename it again, just so we plot it (this copy will get overwritten)
            eval(str2);
            switch regmodel2start
                case 'param'
                    subplot(1,4,1:2); plot(N1v,plotvec,'r.-'); hold on
                case 'nonparam'
                    subplot(1,4,1:2); plot(Q.fitd_nonpar_vals(:,1),Q.fitd_nonpar_vals(:,2),[col '.-']); hold on
            end
            stock_and_harvr = sortrows([Q.states_blk(~isnan(Q.action_blk)).*Q.shock_blk(~isnan(Q.action_blk)) 1-Q.Av(Q.action_blk(~isnan(Q.action_blk)))],1);
            subplot(1,4,3:4); plot(stock_and_harvr(:,1),1-stock_and_harvr(:,2),'r.-'); hold on
            n_reg_vec(repFDP) = Q.n_reg;
            n_sim_decss_vec(repFDP) = Q.n_sim_decss;
        end
    end
end
n_reg_vec  %number of regressions before conv
n_sim_decss_vec  %numer of sims at switch to dec ss.
subplot(1,4,1:2); plot(N1v,Vbar_VFI,'b.-'); 
%ylim([0,380]); %base
ylim([0,600]); 
if     strcmp(poly_modelcompare,'quadratic'); ylim([0,2100]); 
elseif strcmp(poly_modelcompare,'cubic');     ylim([0,700]); 
elseif strcmp(poly_modelcompare,'quartic');   ylim([0,800]); 
end
xlim([0,205])
subplot(1,4,3:4); plot(N1v,action_VFI,'b.-'); ylim([.25, 1])
legendstring = [legendstring  '''VFI'''];
subplot(1,4,1:2); ylabel('V(N)'); xlabel('N');     
str = ['title(' '''' 'compare methods of estimating value function assuming ' bio_model_c ' recruitment.' '''' ')'];
eval(str);
str = ['legend(' legendstring ', ''Location'',''Best'')'];
eval(str);
%ylim([0,600]); 
grid on
subplot(1,4,3:4); ylabel('A(N)'); xlabel('N');  
grid on

subplot(1,4,3:4); eval(str);