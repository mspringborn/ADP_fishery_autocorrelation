% sc_getpolfun 
% Obtain the policy function (Policy_Fun) for a set of state space nodes (x_node)
% Policy_Fun is the optimal esc level given a particular x_node slice, where N is
% post growth stock and z's are post stoch shock levels.
% Loops here are time consuming, e.g. ~8 hrs for 66K different nodes.

if noprofshock || nobiolshock % if profit or biological shocks turned off
    x_node_backup = x_node; 
    if m==0  
        if noprofshock % no profit shocks and M=0 means policy is a function of only the stock
            [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1v,1,1,1,1);    % 
        elseif nobiolshock
            [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1v,1,1,pv,cv);    % 
        end
    elseif m>0 
        if noprofshock % no profit shocks and M>0 means only a func of N,K,R
            [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1v,Kv,Rv,1,1);    % 
        elseif nobiolshock % no profit shocks and M>0 means only a func of N,p,c
            [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1v,1,1,pv,cv);    % 
        end
    end
    x_node = [N1nd(:), Knd(:), Rnd(:), pnd(:), cnd(:)]; 
end

%% Core calculation below takes hours, state space is divided into "nChunks" to follow progress.
nXnd    = size(x_node,1);
if noprofshock || nobiolshock % Smaller state space means no need to chunk. 
    nChunk  = 1; 
else
    nChunk  = 3;
end
szChunk = nXnd/nChunk;  
if szChunk~=round(szChunk); error('Size of chunk not whole number'); end

Policy_Fun_ind = zeros(nXnd,1);
if     strcmp(systmodel,'base')   ; Gf = G_logist_std_multshock; 
elseif strcmp(systmodel,'critdep'); Gf = G_logist_cdep_multshock;
end                
tic
for i = 1:nChunk        % outer loop over state space chunks.
    Policy_Fun_i = zeros(szChunk,1);
    x_node_i     = x_node((1+(i-1)*szChunk):(szChunk*i),:);   % block of x_node to be executed in loop i.
    parfor k = 1:szChunk  % for every state vector in this chunk
%debugging (without parfor):
% x_node_i = x_node_i(x_node_i(:,3)==1.5,:);
% disp('parfor in get pol is off!'); dpf = 0; 
%     for k = 1:szChunk  % for every state vector
        if x_node_i(k,1)==0     %if N=0, set escapement share to max.
            Policy_Fun_i(k) = nA; %used to be set to index of 1, the min esc but won't matter; 
        else
            if dpf; 
                pfw = getCurrentTask(); pfwid = pfw.ID; %warning('off','File not found or permission denied');
            else
                pfwid = 1; 
            end %get worker id to keep saved data file names distinct.
            states = x_node_i(k,1);  % Just the stock

            z = x_node_i(k,2:nx);  %! Note for shock levels, x_node will be specifying the POST-disturbance shock level (rather than the pre-)...we're just cycling through cases here and want post-disturbance cases.
            % Note: x_node N is interpreted as post-grow stock
            pi_a         = PI_netprof_mult(z(3),z(4),states,Av);
            nextstates_a = min(xMinMax(2,1),states*Av); 
            polAppVer = 'x_node(:,1) serves as post-growth stock';

            states_ph = x_node_i(k,:); % just a placeholder to hold the fitting location--will be dropped
            if states(1) == 0 || all(nextstates_a==0)  % if N is already 0 or N is going to be 0 no matter what action
                Vn_a     = zeros(size(nextstates_a));   
            else
                if m==0
                    Vn_a = predict(Vfit,txfun(nextstates_a)); 
                elseif m>0
                    Vn_a = predict(Vfit,[txfun(nextstates_a) repmat(z(:)',[nA,1])]); 
                end
            end
            Vn_a = reshape(Vn_a, size(pi_a));  %Ensure that Vn_a and pi_a vectors are same orientation.
            % Calc PV of each possible action 
            V_a  = pi_a + delta*Vn_a;    %viz: figure(77); plot(Av,delta*Vn_a','.-'); xlabel('action'); ylabel('delta*Vn_a'); figure(78); plot(Av,V_a,'.-'); xlabel('action'); ylabel('V_a');            
            % Identify maximized value and index of optimal action.
            [~, Policy_Fun_i(k)]        = max(V_a(:));  % [~, tempi]        = max(V_a(:))
        end
    end
    Policy_Fun_ind((1+(i-1)*szChunk):(szChunk*i)) = Policy_Fun_i;
    Policy_Fun_i = 0*Policy_Fun_i; % reset.
    disp(['Chunk ' num2str(i) ' of ' num2str(nChunk) ' complete'])
    save('tempPfun.mat','Policy_Fun_ind');  % Save in case loop is interrupted
end
toc
Policy_Fun = Av(Policy_Fun_ind); % get action value

%% if there is no profit shock, expand policy functions (replicate) to keep common 5-dimensional form. Restor x_node
if noprofshock || nobiolshock % if profit or biological shocks turned off
    if m==0  
        if noprofshock % no profit shocks and M=0 means policy is a function of only the stock
            Policy_Fun = repmat(Policy_Fun,[1,nK,nR,np,nc]);     % 
        elseif nobiolshock
            Policy_Fun = reshape(Policy_Fun,[nN1,np,nc]);  % reshape to array form...
            Policy_Fun = repmat(Policy_Fun,[1,1,1,nK,nR]); % ...temporarily put exanding dimensions (nK,nR) at end 
            Policy_Fun = permute(Policy_Fun,[1 4 5 2 3]);  % ...put dimensions in correct order
        end
    elseif m>0 
        if noprofshock % no profit shocks and M>0 means only a func of N,K,R
            Policy_Fun = reshape(Policy_Fun,[nN1,nK,nR]);  % reshape to array form...
            Policy_Fun = repmat(Policy_Fun,[1,1,1,np,nc]); % ...expand over degenerate dimensions
        elseif nobiolshock % no profit shocks and M>0 means only a func of N,p,c
            Policy_Fun = reshape(Policy_Fun,[nN1,np,nc]);  % reshape to array form...
            Policy_Fun = repmat(Policy_Fun,[1,1,1,nK,nR]); % ...temporarily put exanding dimensions (nK,nR) at end 
            Policy_Fun = permute(Policy_Fun,[1 4 5 2 3]);  % ...put dimensions in correct order
        end
    end
    Policy_Fun = Policy_Fun(:);                    % ...return to vector form, same length as orig x_node.
    x_node = x_node_backup; clear x_node_backup; %restore
end



