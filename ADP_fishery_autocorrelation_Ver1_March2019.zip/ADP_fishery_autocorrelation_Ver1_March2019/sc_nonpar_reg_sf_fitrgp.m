% sc_nonpar_reg_sf_fitrgp
% Run regression using Matlab's nonparametric routine fitrgp

%% Some inelegant renaming here... 
states_blk_aug = [states_blk];
Vbar_blk_aug   = [Vbar_blk];
if ~multTCorrShk 
    useCols = 1; 
elseif multTCorrShk
    if m==0; useCols = 1;   % use only stock
    else;    useCols = 1:nx; % use all columns.
    end
end
%% Function to transform stock variable to deal with kinks--there is "art" in selecting powTx
% powTx in (0,1]. 1=no transformation.  Closer to zero to handle kink near zero
if     strcmp(systmodel,'critdep') 
    %powTx=.3; txfun = @(N)  xMinMax(2,1)*(N/xMinMax(2,1)).^powTx; 
    % Note: for constant MC of harvest, used txfun = N for m0, other for m95.
    if nx>1      % True for multTCorrShk when m>0 
        %txfun = @(N)  N; % No transformation
        powTx=.3;      
    elseif nx==1 && multTCorrShk % True for multTCorrShk when m==0
        powTx=.1; 
    elseif ~multTCorrShk 
        powTx = .3;
    end
    txfun = @(N)  xMinMax(2,1)*(N/xMinMax(2,1)).^powTx;        
elseif strcmp(systmodel,'base') || strcmp(systmodel,'rick')% power of 0.1 handles elbow near zero.   
    powTx=.1; 
    %powTx=1;
    txfun = @(N)  xMinMax(2,1)*(N/xMinMax(2,1)).^powTx; 
end   
%figure(12); hold on; plot(N1v,txfun(N1v)); grid on; xlabel('raw N'); ylabel('tx N'); % Specify concave power tranformation function to "stretch out" low values (i.e. stretch the resulting function near the kink)
states_blk_aug_use = states_blk_aug(:,useCols);
states_blk_aug_use(:,1) = txfun(states_blk_aug(:,1)); % Transform only state variable with value function kink (here N).


%% Run regression
%Add stock of zero with value of zero (this is known) to simple model (to pin origin of function).  Zero stock is handled in the sampling (sc_FDP_shocks.m) for mulTCorrShk.
if ~multTCorrShk
    Xgpreg = [0; states_blk_aug_use];  
    Ygpreg = [0; Vbar_blk_aug];
else
    Xgpreg = [states_blk_aug_use];  
    Ygpreg = [Vbar_blk_aug];
end
    
Vfit = fitrgp(Xgpreg,Ygpreg,'Standardize',1,'KernelFunction',kernfun);

if 0 %plot Vfit for m=0.
    %%
%     kpinit = [std(states_blk_aug(:,useCols)); std(Vbar_blk_aug)/2]; %default
%     kpinit = [kpinit(1) kpinit(2)*10];  'KernelParameters',kpinit
    gpsigcon =50;
    kparams0 =[2 4];
    Vfit = fitrgp(states_blk_aug(:,useCols),Vbar_blk_aug,'Standardize',1,'KernelFunction',kernfun,'Sigma',gpsigcon,'ConstantSigma',true,'KernelParameters',kparams0); %,,'BasisFunction',basisfun
    figure(117); subplot(1,2,1); ezplot(@(N1vec) (predict(Vfit,N1vec)),[xMinMax(:,1)']); grid on;
                 subplot(1,2,2); ezplot(@(N1vec) (predict(Vfit,N1vec)),[xMinMax(:,1)']); grid on; ylim([0,600])
end

%% Get fitted values: 
%(1) at observations...
Vpred_blk_aug = predict(Vfit,states_blk_aug_use);
Vpred_blk_aug(states_blk_aug(:,1)==0)=0;  %override stock = 0 case.
fitd_nonpar_vals = unique([states_blk_aug Vpred_blk_aug],'rows'); %unique & sorted (by stock level) fitted values across all states_blk
fitd_nonpar_vals(fitd_nonpar_vals(:,nx+1)<0,2) = 0;
%...and (2) at nodes:
x_node_use = x_node(:,useCols);
x_node_use(:,1) = txfun(x_node(:,1));
Vbar = predict(Vfit,x_node_use);
Vbar(x_node(:,1)==0)=0;

return


