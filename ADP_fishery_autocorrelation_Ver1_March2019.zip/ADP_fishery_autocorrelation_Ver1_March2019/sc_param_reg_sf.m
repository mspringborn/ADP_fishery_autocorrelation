 % sc_param_reg_sf: parametric regression   

% Stats for centering and scaling the data:
Vstd  = std(Vbar_blk);      Vmean = mean(Vbar_blk);
xstd  = std(states_blk);    xmean = mean(states_blk); 

if regmodel==2 %specify regression model--use "late" form (as opposed to early "simple" form).
    valuefun=valuefun_late;  
end

% Parametric regression:
mdl              = fitlm(fi_cs(states_blk,xmean,xstd),fi_cs(Vbar_blk,Vmean,Vstd),valuefun); 
[warnmsg, msgid] = lastwarn;

% Perhaps cut or tune this: 
if 0 
    % Check regression: Once sufficiently far along (regmodel==2, n_sim since nswitch is not low) and check to see if the regression was problematic (very low R^2 or rank deficient).
    if (mdl.Rsquared.Adjusted < 0.5 || strcmp(msgid,'stats:LinearModel:RankDefDesignMat')==1) && regmodel == 2 && n_sim-nswitch > 30*length_blk
        error('Problem with regression')
        %Note: if regressions become unstable, Tikhonov regularization can be used.
    end
end

Vbar      = fi_predict_cs(mdl,x_node,xstd,xmean,Vstd,Vmean);  
Vbar(ext) = 0;  %Whereever the population is extinct, ensure value zero.
beta0     = mdl.Coefficients.Estimate;     



