% sc_plot_V_and_policy_final
% Generate value and policy plots for a given systmodel for simple single growth shock model 

clear
systmodels  = {'base','critdep'}; 
regmodels   = {'nonparam','param'};
poly_models = {'quadratic','cubic','quartic'};

% choose base or crit dep to plot:
systmodel = systmodels{1};  %toggle between 1 and 2

% FDP nonparametric model version:
if 1 % main case
    ver = '17'; verVFI = []; snstvty=0;
else % specify sensitivity analysis case
    snstvty=2;
    if     snstvty==1; ver = 'Kp10';  % repFDP 3 is a bit off on the value function but otherwise they look reasonable
    elseif snstvty==2; ver = 'Km10'; 
    elseif snstvty==3; ver = 'Cp10'; 
    elseif snstvty==4; ver = 'Cm10'; 
    end
    verVFI = ver;
end
repFDP=1; 
 for repFDP=1:1%10; pause  %<--Turn on to look at replicants of an FDP solution.
% escapement can be plotted as a level or a share of the stock:
%esc_form='share'; 
esc_form='level'; 

% For saving set loc for figures (figloc) and loading arrays (saveloc)
cdall   = cd; figloc = [cdall(1:end-4) 'Writing\figs\'];
saveloc = 'output\solutions\'; 

% Comparison of various models (V and policy) for base or critdep
figname = ['value_policy_fun_comp_' systmodel '_' esc_form]; 
stdy_st_pol_minmax = []; % Gather constant escapement policy level

% Nodes to plot for FDP-nonparam
N1vtemp  = [1:200]; % Nodes to plot for FDP-nonparam
N1vtemp2 = [1:5:200 200]; 

% Load VFI solution
filename = [saveloc 'soln_VFI_' systmodel verVFI];
Q = load(filename);
Vbar_VFI = Q.Vbar;
action_VFI = Q.action;
N1v = Q.N1v;

fig = 2; figure(fig); clf;
figw=9; figh=3.5;
set(gcf,'Units','inches','Position',[3, .4, figw, figh])  
set(gcf,'Color','w')
legendstring=[]; 

%Plot VFI output and tweak figures.
legendstring = [legendstring  '''VFI: lookup table''' ','];

%vfisty = ['c-']; lw = 2; 
vfisty = ['k-*']; lw = 1; 
mind = [1    14     50    60    69    78    86    94]; [1 cumsum(14:-1:5)]; %1:5:length(Vbar_VFI)
subplot(1,2,1); 
    plot(N1v,Vbar_VFI,vfisty,'LineWidth',lw,'MarkerIndices',mind); hold on 
subplot(1,2,2); 
    if strcmp(esc_form,'share') 
        esc = action_VFI;       ylimesc=[0.15,1]; 
    elseif strcmp(esc_form,'level')
        esc = action_VFI.*N1v;  ylimesc=[0,80]; 
        % Gather constant escapement policy level, in place when n>100 for all policies.
        stdy_st_pol_vec    = esc(N1v(:)>100); 
        stdy_st_pol_minmax = [stdy_st_pol_minmax; min(stdy_st_pol_vec) max(stdy_st_pol_vec)]; 
    end
    plot(N1v,esc,vfisty,'LineWidth',lw,'MarkerIndices',mind); hold on  %1:5:length(esc)

addl=[];
col = 'mbr'; mrk = {':','--','-.'};
lw = 2;  %linewidth

for i = 1:numel(regmodels)
    regmodel2start = regmodels{i};
    if strcmp(regmodel2start,'nonparam'); J=1; else J=numel(poly_models); end
    for j = 1:J
        %repFDP=7;  %use first FDP solution for nonparam model
        switch regmodel2start
            case 'param'
                poly_model     = poly_models{j};
                if       snstvty==0; verParam = [];  addnm = '_wt_equal_obs';
                elseif   snstvty>0;  verParam = ver; addnm = []; 
                end
                filename = [saveloc 'soln_FDP_' systmodel verParam '_' regmodel2start '_' poly_model addnm '_rep_' num2str(repFDP)];
                legendstring = [legendstring  '''' regmodel2start ' ' poly_model ''''  ','];               
            case 'nonparam'
                kernfun = 'ardmat52';
                %filename = [saveloc addl 'soln_FDP_' systmodel '_' regmodel2start '_wt_equal_obs_rep_' num2str(repFDP)];  
                filename = [saveloc addl 'soln_FDP_' systmodel ver '_' regmodel2start kernfun '_rep_' num2str(repFDP)];                           
                legendstring = [legendstring  '''' regmodel2start ' '''  ','];
        end
        Q=load(filename); 
%             newnameVbar = ['Vbar' '_' num2str(i) num2str(j)];  %
%             str = [newnameVbar '= Q.Vbar;']; %rename Vbar once, so we hold on to it
%             eval(str);
%             str2 = ['plotvec =' newnameVbar ';']; %rename it again, just so we plot it (this copy will get overwritten)
%             eval(str2);
        subplot(1,2,1) 
            switch regmodel2start
                case 'param'
                    psty = [col(j) mrk{j}]; 
%                         if strcmp(version,'9.1.0.441655 (R2016b)');
%                             mi = ',''MarkerIndices'',1:5:length(N1v)'; 
%                         else 
%                             mi = []; 
%                         end

                    plot(N1v,Q.Vbar,psty,'LineWidth',lw);  
                case 'nonparam'
                   %psty = 'k*';
                   psty = 'c-';
                   %fitdtemp = interp1(Q.fitd_nonpar_vals(:,1),Q.fitd_nonpar_vals(:,2),N1vtemp,'pchip');
                   %plot(N1vtemp,fitdtemp,psty,'LineWidth',lw);
                   yy = ezplot(@(N1vec) (predict(Q.Vfit,Q.txfun(N1vec))),[0,200]);  title('')
                   set(yy,'Color',psty(1),'LineWidth',lw)
                   VfitNP = Q.Vfit; txfunNP = Q.txfun; % Used below.
            end
            hold on
        stock_and_harvr = sortrows([Q.states_blk(~isnan(Q.action_blk)).*Q.shock_blk(~isnan(Q.action_blk)) 1-Q.Av(Q.action_blk(~isnan(Q.action_blk)))],1);
        subplot(1,2,2);
            N1vt =  N1vtemp2;
%             if strcmp(regmodel2start,'nonparam'); %if nonparm, replace super-dense, irregularly spaced vectors with regularly spaced vector for plotting.
%                 pfuntemp = interp1(stock_and_harvr(:,1),stock_and_harvr(:,2),N1vtemp,'pchip'); 
%                 stock_and_harvr = [N1vtemp(:) pfuntemp(:)];
%                 lw = 1; 
%                 N1vt =  N1vtemp;
%             end
            if strcmp(esc_form,'share') 
                esc = (1-stock_and_harvr(:,2)); 
            elseif strcmp(esc_form,'level')
                esc = stock_and_harvr(:,1).*(1-stock_and_harvr(:,2)); 
            end
            if strcmp(esc_form,'level')
                stdy_st_pol_vec    = esc(stock_and_harvr(:,1)>100); 
                stdy_st_pol_minmax = [stdy_st_pol_minmax; min(stdy_st_pol_vec) max(stdy_st_pol_vec)]; % Gather constant escapement policy level, in place when n>100 for all policies.
            end
            if strcmp(regmodel2start,'nonparam'); %if nonparm, replace super-dense, irregularly spaced vectors with regularly spaced vector for plotting.
                esc = interp1(stock_and_harvr(:,1),esc,N1vtemp,'linear'); 
                pfuntemp = interp1(stock_and_harvr(:,1),stock_and_harvr(:,2),N1vtemp,'pchip'); 
                stock_and_harvr = [N1vtemp(:) pfuntemp(:)];
                N1vt =  N1vtemp;
            end
            lw = 2; 
            plot(N1vt,interp1(stock_and_harvr(:,1),esc,N1vt,'pchip'),psty,'LineWidth',lw); hold on

%             n_reg_vec(repFDP) = Q.n_reg;
%             n_sim_decss_vec(repFDP) = Q.n_sim_decss;

    end
end

% n_reg_vec  %number of regressions before conv
% n_sim_decss_vec  %numer of sims at switch to dec ss.

%tweak figures.
legstr = ['h = legend(' legendstring '''Location'',''Best'');'];
subplot(1,2,1); 
    if     strcmp(systmodel,'base');     ylim([100,500]);  xlim([0,200])
    elseif strcmp(systmodel,'critdep');  ylim([-5,800]);    xlim([0,200])
    end
    ylabel('value'); xlabel('\it{n}');     
    eval(legstr); legtitle = 'Value function model'; set(get(h,'title'),'string',legtitle);
    grid on
subplot(1,2,2); 
    if strcmp(esc_form,'share') 
        ylimesc=[0.15,1]; 
    elseif strcmp(esc_form,'level')
        if     strcmp(systmodel,'base');     ylimesc=[0,80];
        elseif strcmp(systmodel,'critdep');  ylimesc=[0,90];
        end 
    end
    ylim(ylimesc); xlim([0,200])
    ylabel('escapement'); xlabel('post-shock stock, \it{n*z}');  
    grid on
    eval(legstr); set(get(h,'title'),'string',legtitle);

if 0
    print([figloc figname],'-depsc','-painters')
    print([figloc figname],'-dpng','-r0')  
end
if 1
    if strcmp(esc_form,'level')
        % Get constant escapement levels and %-diff from VFI solution.
        disp('First make sure min (column1) and max (column2) escapement values are very close (i.e. constant escapement is constant)')
        stdy_st_pol_minmax 
        con_esc_mdls = mean(stdy_st_pol_minmax,2); 
        percdiff_VFI = 100*(con_esc_mdls-con_esc_mdls(1))./con_esc_mdls;
        rep = [con_esc_mdls percdiff_VFI]; rep = .1*round(rep*10); %round to single decimal
        disp(['Constant escapement for ' systmodel ' and perc diff from VFI (same order as figure legend):'])
        disp(['Version: ' ver])
        disp(array2table(rep,'VariableNames',{'Escapement','Perc_change_from_VFI'})) 
        
        %% Assess error from FDP solution:
        Nce  = con_esc_mdls(2);     % Get optimal policy--a constant escapement level.
        if 1
            Gf = Q.G_logist;        % Growth function. Warning: naming convention changed--in recent solutions use Q.Gf.
        else
            Gf = Q.Gf; 
        end
        NceG = Gf(Nce);           % Apply growth. Typical stock at end and beginning of periods (as long as stock is recovered) given constant escapement and growth, NceG
        %Nvec2check= NceG;              % Stock at which to check the error
        Nvec2check= NceG*[.05:.05:1.20];              % Stock at which to check the error
        %Nvec2check= 10:10:120;
        ErrStat = [];
        for NchEr = Nvec2check 
            IndH = @(z) z*NchEr > Nce; % Indicator for whether post-shock stock is greater than escapement and thus there will be some Harvest.
            PIz  = @(z) IndH(z).*Q.PI_netprof(z,NchEr,Nce./(z*NchEr));    % Only profit if some Harvest.  3rd arg of profit function is escapement share
            Vfun = @(N) predict(VfitNP,txfunNP(N'))';                    % N needs to be a row vector (for integral) but a column vector for predict. 
            Vz   = @(z) IndH(z).*Vfun(Gf(Nce)) + (1-IndH(z)).*Vfun(Gf(z*NchEr)); % Next state is either constant escapment level+growth (if post shock stock > const esc) or the post shock stock itself (if post shock stock >= const esc) 
            Intgd= @(z) pdf(Q.PDF_shock,z).*(PIz(z) + Q.delta*Vz(z));    % The integrand
            Vcalc= integral(Intgd, Q.minz,Q.maxz); 
            Error= Vfun(NchEr) - Vcalc; 
            ErrPc= 100*Error/Vfun(NchEr);
            ErrStat = [ErrStat; [Error ErrPc]];
        end
        disp('Examine value function error in the contraction mapping for FDP')
        disp(array2table([Nvec2check' ErrStat],'VariableNames',{'Stock_N','Raw_error','Perc_error'})) 
         
        %

    end
end
end
if 0 % Plot inverse growth function curve--intersection with escapement policy is SS if there are no shocks.
   subplot(1,2,2); plot(Q.G_logist(N1v(N1v<=Q.K)),N1v(N1v<=Q.K),'-g'); 
   % Intersections for VFI, nonparm, quad, cubic, quartic (col 1: base; col 2 critdep):
   ssDetEsc=[56.92 74.61
    56.98  74.85
    69.09 81.00
    46.78 73.23
    32.70 63.45];
   perDevVFI = 100*((ssDetEsc-repmat(ssDetEsc(1,:),[5,1]))./repmat(ssDetEsc(1,:),[5,1]));
end

%% Examine multiple FDP solutions for reliability.  
if 1
    tempout=[];
    for repFDP=1:10
        Q=load(['output\solutions\soln_FDP_' systmodel ver '_nonparamardmat52_rep_' num2str(repFDP)]);
        stock_and_harvr = sortrows([Q.states_blk(~isnan(Q.action_blk)).*Q.shock_blk(~isnan(Q.action_blk)) 1-Q.Av(Q.action_blk(~isnan(Q.action_blk)))],1);
        esc = stock_and_harvr(:,1).*(1-stock_and_harvr(:,2)); 
        stdy_st_pol_vec    = esc(stock_and_harvr(:,1)>100);   
        tempout=[tempout; [Q.n_reg Q.time4fdp/60 min(stdy_st_pol_vec) max(stdy_st_pol_vec)]];   
        clear Q
    end
    CEvfi = con_esc_mdls(1); %const esc from VFI -- base: 62.1608; critdep: 74.5846.
    tempout = [tempout mean(tempout(:,3:4),2)]; % add CE mean
    tempout = [tempout tempout(:,5)-CEvfi 100*(tempout(:,5)-CEvfi)/CEvfi ];
    tempout = [tempout; mean(abs(tempout))];
    disp('Rows are multiple FDP solutions. Final row is mean accross multiple solutions')
    disp(array2table(tempout,'VariableNames',{'num_reg','runtime_min', 'CE_min','CE_max', 'CE_mean', 'CE_diff_VFI', 'CE_diff_VFI_perc'}))
end

