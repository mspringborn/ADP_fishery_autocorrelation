% sc_plots_sf.m
% Figures to visualize elements of solution process

%% Figures setup
% Make directories for pre-solution "dashplot" figures:
if n_reg == 1
    dash_dir = [cd working_figloc casename '_rep_' num2str(repFDP) '\dashplots'];
    if n_reg==1
        mkdir(dash_dir)
    end
    settings = ['FDP output: '...
                'Reg. every:'          num2str(reg_every)  '; '...
                'Step rate dec.:'      num2str(sp_rate)    '; '...
                'T:'                   num2str(T)                  ];  % for printing with results.
end

%% Start figs....

if fig==1
    %% FDP tracking figure: shows objects as they update: value function, constant term from V model, max-%dev, step-size, other coefficients, history of deviations.      
    fig=1;     
    figure(fig); clf;
    expandplot = 1;     % Additional subplots included
    if expandplot
        figw=12; figh=9;
        set(gcf,'Units','inches','Position',[3.5,0.5,figw,figh]); %[left, bottom, width, height]
        sph=3; spw=3;
    else 
        figw=9; figh=5;
        set(gcf,'Units','inches','Position',[3.5,0.5,figw,figh]); %[left, bottom, width, height]
        sph=2; spw=3;
    end
    set(gcf,'Color','w')
    toplot = 1:n_reg;

    % Plot "data used in regression" 
    subplot(sph,spw,1); %title(settings)
        colormap('hsv'); cmap = colormap; cmap=cmap(1:5:60,:,:); set(gcf,'DefaultAxesColorOrder',cmap) 
        scatter(states_blk(:,1), Vbar_blk,25,'.k');  %This is data that was used in regression to update Vbar.
        hold on
        % Plot regressed V:
        if regmodel<3
            ph=plot(N1v(2:end),Vbar(2:end),'-r');
        elseif regmodel==3  
            if ~multTCorrShk
                ph=plot(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,end),'-r');
            elseif multTCorrShk
                %Multivariate value function: plot over stock a middle of other nodes.
                mid_x_node = find(x_node(:,2)==Kv(round(nK/2)) & x_node(:,3)==Rv(round(nR/2)) & x_node(:,4)==pv(round(np/2)) & x_node(:,5)==cv(round(nc/2))); % middle of non-stock vectors
                ph=plot(x_node(mid_x_node,1),Vbar(mid_x_node),'-r*');  
            end
        end
        %title({['Vbar and new obs scatter']})
        xlabel('stock, \it{n}'); 
        ylabel('value'); %title('Regression step: data are from Vbar (circles), regression output in lines, colorbar indicates Z'); 
        h=legend('$\mathbf{\widetilde{V}}$','$\bar{V}^k$'); set(h,'Interpreter','latex','Location','Best','FontSize',12)
        grid on; box on
        yl = ylim; yl(1) = 0; ylim(yl)
        %xlim([30,100])%ylim([0,35]); xlim([0,20])

    % Regression residuals.
    subplot(sph,spw,2)
        switch regmodel2start 
            case 'param'
                resid = Vbar_blk - f_predict_w0_sf(mdl,states_blk,xstd,xmean,Vstd,Vmean,N1v,fi_predict_cs,[],x_node,Vbar); %rshp to []
            case 'nonparam'
                %resid = Vbar_blk - interp1(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2), states_blk,'pchip');
                Vpred_blk = Vpred_blk_aug(1:length(Vbar_blk)); %Remove the "augmented" nodes
                resid = Vbar_blk - Vpred_blk;
        end
        scatter(states_blk(:,1),resid,25,'.b');
        hold on; gg=ezplot(@(n) 0, [0,max(states_blk(:,1))]); set(gg,'Color','k')%,'Width',2)
        grid on; box on;
        xlabel('stock, \it{n}'); 
        ylabel('residuals');
        title('')
        yl = ylim; ylim(max(abs(yl))*[-1 1]);  %makes limits symmetric around zero
        %xlim([30,100])%xlim([0,20])

        
    % Max Deviation
    subplot(sph,spw,3)
        plot(toplot,maxdev(toplot),'r:','LineWidth',1.5); hold on
        plot(toplot,maxdevavg(toplot),'k-')
        xlabel('regression count, \it{k}'); ylabel('convergence statistic'); 
        legend('single update.','10-update. avg.','Location','Best') 
        h=legend('$\Delta_k$','rolling avg. $\Delta_k$'); set(h,'Interpreter','latex','Location','Best');
        grid on;   
        ylim([0,10])
        if n_reg>100; ylim([0,2]); grid on; end

    subplot(sph,spw,4)
        if 0
            stock_and_harvr = sortrows([states_blk(~isnan(action_blk),1).*shock_blk(~isnan(action_blk)) 1-Av(action_blk(~isnan(action_blk)))],1);
            plot(stock_and_harvr(:,1),stock_and_harvr(:,2));
            %hold on; scatter(states_blk(~isnan(action_blk)),1-Av(action_blk(~isnan(action_blk))),4,shock_blk(~isnan(action_blk)));  % these are preshock N...
            ylabel('policy: harvest rate'); ylim([0,.85])
        else
            keep=~isnan(action_blk); 
            if ~multTCorrShk 
                stock_and_harvr = sortrows([states_blk(keep).*shock_blk(keep)          1-Av(action_blk(keep))],1);
                preharvn = 'n*z';  linsp = '-r';
            else
                stock_and_harvr = sortrows([Gf(shock_blk(keep,1),shock_blk(keep,2),states_blk(keep,1))     1-Av(action_blk(keep))],1);
                preharvn = 'G(z,n)'; linsp = '.r';
            end
            %stock_and_harvr = sortrows([states_blk(~isnan(action_blk)) 1-Av(action_blk(~isnan(action_blk)))'],1);
            plot(stock_and_harvr(:,1),stock_and_harvr(:,1).*(1-stock_and_harvr(:,2)),linsp);
            approx_CE = mean(stock_and_harvr(end-20:end,1).*(1-stock_and_harvr(end-20:end,2))); % Using last 20 nodes.
            use4mean = find(stock_and_harvr(:,1)>approx_CE)+10; %plus 10 for buffer
            approx_const_esc1 = mean(stock_and_harvr(use4mean:end,1).*(1-stock_and_harvr(use4mean:end,2)))
            
            esc = stock_and_harvr(:,1).*(1-stock_and_harvr(:,2));
            stdy_st_pol_vec    = esc(stock_and_harvr(:,1)>100); 
            stdy_st_pol_minmax = [min(stdy_st_pol_vec) max(stdy_st_pol_vec)]; 
            approx_const_esc2 = mean(stdy_st_pol_minmax)
           
            %hold on; scatter(states_blk(~isnan(action_blk)),1-Av(action_blk(~isnan(action_blk))),4,shock_blk(~isnan(action_blk)));  % these are preshock N...
            ylabel({'policy:','escapement, \it{' preharvn ' - h}'}); %ylim([0,.85])
        end
        xlabel(['post-shock stock, \it{' preharvn '}']);  
        xlim([0,max(stock_and_harvr(:,1))]); 
        grid on
    
    % stepsize
    subplot(sph,spw,5)
        plot(1:(n_reg),meanstep(1:(n_reg)),'-');  %stepstore
        xlabel('regression count, \it{k}'); ylabel('step size, \it{\delta}'); 
        grid on

    % reg model and step-size metric:
    subplot(sph,spw,6)

        plot(1:n_reg,ss_stepsize(1:n_reg), 'r:','LineWidth',1.5);  hold on %
        
        grid on;  hold on 
        %show threshold levels:
        plot(1:n_reg,thresh_sw_ss+0*(1:n_reg),'--b')
        
        if n_reg>10; 
            plot(11:n_reg,ss_stepsize_met(11:n_reg), 'k-'); 
            h=legend('each reg., \it{k}','threshold','rolling avg.');
        else
            h=legend('each reg., \it{k}','threshold');
        end
        xlabel('regression count, \it{k}'); 
        %ylabel({'step size switch stat', 'mean dev. as % of mean value'}) 
        ylabel({'decl. step size trigger'})%, 'mean dev. as % of mean value'}) 
        %legend('iteration stat','moving avg stat','thresh','Location','Best')
        set(h,'Location','Best'); 


        yl = ylim; ylim(max(abs(yl))*[-1 1]);  %makes limits symmetric around zero 
%        if n_reg>20; ylim(10*[-thresh_sw_ss thresh_sw_ss]); end
        if n_reg>20; ylim([-3 3]); end

        if expandplot
            if multTCorrShk
                subplot(sph,spw,7) % value over stock for various Ks, all others at midpoints.
                    mPt  = round([nN1,nK,nR,np,nc]/2);                  %mid-points of state vectors
                    getrz = find(x_node(:,3) == Rv(mPt(3)) & x_node(:,4) == pv(mPt(4)) & x_node(:,5) == cv(mPt(5)));
                    toPltV = reshape(Vbar(getrz),nN1,nK); 
                    if ismember(n_reg,0:5:400); txfun_use = @(N) N; 
                    else                        txfun_use = txfun; 
                    end  % Every 2 or 5 iterations plot the transformed function.
                    if m==0
                        ezplot(@(N1vec) (predict(Vfit,txfun_use(N1vec))),[xMinMax(:,1)']); grid on
                    elseif m>0
                        for jk = 1:nK
                            ezplot(@(N1vec) predict(Vfit,[txfun_use(N1vec(:)) Kv(jk)+0*N1vec(:) repmat(1,[length(N1vec),nx-2])]),[xMinMax(:,1)']); grid on; hold on 
                        end
                    end
                    yLimits = get(gca,'YLim'); ylim([0 yLimits(2)]);
                    xlabel('stock'); ylabel('V'); title('')
                subplot(sph,spw,8)
                        plot(Kv,toPltV','.-b');
                        xlabel('K'); ylabel('V')               
                subplot(sph,spw,9) % value over stock for various Ks, all others at midpoints.
                        mPt  = round([nN1,nK,nR,np,nc]/2);                  %mid-points of state vectors
                        getrz = find(x_node(:,2) == Kv(mPt(2)) & x_node(:,4) == pv(mPt(4)) & x_node(:,5) == cv(mPt(5)));
                        toPltV = reshape(Vbar(getrz),nN1,nK); 
                        plot(Rv,toPltV,'.-b');
                        xlabel('R'); ylabel('V')              
            elseif ~multTCorrShk       
                if ismember(n_reg,0:5:400); txfun_use = @(N) N; ttl='Transformed function'; 
                else                        txfun_use = txfun;  ttl = '';
                end  % Every 2 or 5 iterations plot the transformed function.

                subplot(sph,spw,7) % fitted model just estimated.
                        ezplot(@(N1vec) (predict(Vfit,txfun_use(N1vec))),[0,200]); grid on; title(ttl)
                %subplot(sph,spw,8) % 
               
                %% under cgam:
                if 0 
                subplot(sph,spw,7)
                    bar(N1v(~excl_smallV),devraw(~excl_smallV));
                    xlim([-1,max(N1v)+1]);
                    ylabel('% dev')
                    yl = ylim; ylim(max(abs(yl))*[-1 1]);  %makes limits symmetric around zero
            %         hold on; plot(17.75*[1 1],[-1,1],'-g');xlim([10,30])

                if strcmp(regmodel2start,'nonparam')
                subplot(sph,spw,8)                 
                    scatter(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,end),'.k')%.-'); 
                    xlabel('N'); ylabel('V: NP-reg fitted'); grid on; hold on
                    plot(N1v, Vpred_blk_aug(end-(length(x_node)-1):end),'r.-');       
                    legend('all data','state nodes','Location','Best');
                            %ylim([380,450]);  %
                    %Manual past from R:
                            knts=[0.00000  12.00000  15.43852  19.03722  27.10138  33.75321  41.92393  55.12396  84.16095 124.02632 163.96434 200.00000];
                            knts=[0.000000   1.020304   4.081216   9.182736  16.324865  25.507601  36.730946  49.994898  65.299459  82.644628 100.000000];
                    plot(knts,interp1(fitd_nonpar_vals(:,1),fitd_nonpar_vals(:,2),knts,'pchip'),'*g');        
                end  
                end
            end
        end
        
    if n_sim==reg_every % Set figure title: first regression only
        annotation('textbox', [0 .875 1 0.1], 'String', settings, ...
           'EdgeColor', 'none','HorizontalAlignment', 'center'); 
    end %

%         % Remaining Coefficients
%         subplot(sph,spw,5) 
%         plot(1:n_reg,coefficients(2:length(beta0),1:n_reg)','-')
%         xlabel('regressions'); ylabel('Coeffs (except constant)')
%         rec_coeff = coefficients(2:length(beta0),max(1,(n_reg-15)):n_reg); 
%         ylim([min(rec_coeff(:))-abs(min(rec_coeff(:)))*.25    max(rec_coeff(:))+abs(max(rec_coeff(:)))*.25])

    figname = 'FDP_dash';
    if 1
        if n_reg==1; delete([dash_dir '\*']); end % Clean out any old figures from destination.
        figh=gcf; figh.PaperPositionMode = 'auto';
        print([dash_dir '\' figname '_regno' num2str(n_reg)],'-dpng','-r0')
    end
    if 0  %gen fig for paper
        if meanstep(n_reg) <0.475 
            subplot(sph,spw,1); ylim([150,400])
            subplot(sph,spw,6); ylim([-.5, 3]); set(h,'Location','Best')
            for jj = 1:6
                subplot(sph,spw,jj)
                text(-0.19,1.2,['\bf{(' char('A' + jj - 1) ')}'],'Units', 'Normalized', 'VerticalAlignment', 'Top');          
            end            
%             print([figloc figname],'-depsc','-painters')
%             print([figloc figname],'-dpng','-r0')            
            close all  % before saving workspace
            fname = [figloc figname '_data_4_fig'];
%             save(fname,'-regexp','^(?!(shock_path|randindx|state_set|FDPoutputtable)$).'); %save except large unnecessary variables            
            return
        end    
    end
end


if fig==20
    %% Visualize existing estimate of V and new data 
    fig=20;         
    figure(fig); clf;
    colormap('hsv'); cmap = colormap; cmap=cmap(1:5:60,:,:); set(gcf,'DefaultAxesColorOrder',cmap)
%    N1vec=2:nN1;
    plot(state_v{1}(2:end),Vbar(2:end),'-')                 
    title({['Vbar()'], ['new obs scatter']})
    hold on
    scatter(states_blk, Vbar_blk,25,'+');
    grid on; xlabel('stock');ylabel('V');
    %xlim([0,%N_MSY*1.05])
    sze = [14,1,5,4];       %figure size
    set(gcf,'Units','inches','Position',sze); %[left, bottom, width, height]
    set(gcf,'Color','w')
end

if 0
    %%
    figadd=111; figure(figadd); clf
    if 1 %Residuals plot
        Vpred_blk = Vpred_blk_aug(1:length(Vbar_blk)); %Remove the "augmented" nodes
        resid = Vbar_blk - Vpred_blk;
        labs = {'zK','zR','zp','zc'};
        for ii = 1:4
            subplot(2,2,ii)
            scatter(states_blk(:,1+ii),resid,25,'.b'); % Can show more with size/color but not helpful in most iterations: 1+states_blk(:,1)/10,states_blk(:,1)); 
         %   hold on; iii=1; tmprz = find(states_blk(:,iii)>1.25); scatter(states_blk(tmprz,1+ii),resid(tmprz),25,'.r');
            grid on
            xlabel(labs{ii})
            if ii==1 || ii==3; ylabel('resid'); end
        end
        figname = 'FDP_dash_Resids';
        if 0 %show max residuals and what states they're from -- didn't see anything interesting here.
            residKp = resid(states_blk(:,1)>20); %keep only for larger n.       
            Vbar_blkKp = Vbar_blk(states_blk(:,1)>20); %keep only for larger n.       
            states_blkKp = states_blk(states_blk(:,1)>20,:); %keep only for larger n.
            residPerc = 100*residKp./Vbar_blkKp;
    %        [Y,I] = sortrows(residKp);
            [Y,I] = sortrows(residPerc);

            [Y(1:25) states_blkKp(I(1:25),:);...
            NaN mean(states_blkKp(I(1:25),:))]

             [Y(end-25:end) states_blkKp(I(end-25:end),:);...
            NaN mean(states_blkKp(I(end-25:end),:))]
        end
    elseif 0  %% Get V for each R across all K
        mPt  = round([nN1,nK,nR,np,nc]/2);                  %mid-points of state vectors
        for jv=1:3
        for jj=[1 5 9]
            if jv==1;     getrz = find(x_node(:,3) == Rv(jj) & x_node(:,4) == pv(mPt(4)) & x_node(:,5) == cv(mPt(5)));
            elseif jv==2; getrz = find(x_node(:,3) == Rv(mPt(3)) & x_node(:,4) == pv(jj) & x_node(:,5) == cv(mPt(5)));
            elseif jv==3; getrz = find(x_node(:,3) == Rv(mPt(3)) & x_node(:,4) == pv(mPt(4)) & x_node(:,5) == cv(jj));
            end
            toPltV = reshape(Vbar(getrz),nN1,nK); 
            if jj==1; sp = 1; elseif jj==5; sp = 2; elseif jj==9; sp=3; end
            subplot(3,3,sp+(jv-1)*3)
            plot(N1v,toPltV,'.-b');
            xlabel('stock'); ylabel('V') 
        end
        end
        subplot(3,3,2); title('V for various K over R (top), p (mid), and c (bottom).')
        figname = 'FDP_dash_Vs';
    end
    %%
    figh=gcf; figh.PaperPositionMode = 'auto';
    print([dash_dir '\' figname '_regno' num2str(n_reg)],'-dpng','-r0')
end


if fig==11
    %%  Plot value functions+data and residuals for diff functional forms.
    for fig=11%:12;
        figure(fig); clf;
        figw=7.5; figh=5;
        set(gcf,'Units','inches','Position',[.5,.5,figw,figh]); %[left, bottom, width, height]
        set(gcf,'Color','w')
    end
%    sph=2; spw=2;
    sph=2; spw=3; 
    for j=[1 3 4] %1:4      
        if j==1;      mod='quadratic';      regmodel=2; sp=1;
        elseif j==2;  mod='cubic';          regmodel=2; 
        elseif j==3;  mod='quartic';        regmodel=2; sp=2; 
        elseif j==4;  mod='nonparametric'; regmodel=3; sp=3;
        end
        mid_rez = load(['output/vf_mid_rez/vf_mid_rez_' mod '.mat']); % valuefun_late, n_sim, T
        figure(11);
%        subplot(sph,spw,j); %title(settings)
        subplot(sph,spw,sp); %title(settings)
        % Plot "data used in regression"
        scatter(mid_rez.states_blk, mid_rez.Vbar_blk,25,'.k');  %This is data that was used in regression to update Vbar.
        hold on
        % Plot regressed V:
        if regmodel<3
            ph=plot(mid_rez.state_v{1}(2:end),mid_rez.Vbar(2:end),'-r');
            resid = mid_rez.Vbar_blk - interp1(mid_rez.state_v{1},mid_rez.Vbar, mid_rez.states_blk,'pchip');
        elseif regmodel==3  
            ph=plot(mid_rez.fitd_nonpar_vals(:,1),mid_rez.fitd_nonpar_vals(:,2),'-r');
            resid = mid_rez.Vbar_blk - interp1(mid_rez.fitd_nonpar_vals(:,1),mid_rez.fitd_nonpar_vals(:,2), mid_rez.states_blk,'pchip');
        end
        if j==1
            h=legend('$\mathbf{\widetilde{V}}$','$\bar{V}^k$'); 
            set(h,'Interpreter','latex','Location','Best','FontSize',12)
        end
        
        
        if j==1;     ylim([250,600]); %xlim([-1,50]); % valuefun_late, n_sim, T
        elseif j==2; ylim([250,600]); %
        elseif j==3; ylim([250,600]); %
        elseif j==4; ylim([250,600]); %
        end
        title(mod,'FontWeight','Normal')
%         if j==3 || j==4; xlabel('stock, \it{n}'); end
%         if j==1 || j==3; ylabel('\it{V}'); end
        grid on
%        figure(12);
%             subplot(sph,spw,j);
            subplot(sph,spw,sp+3);
            scatter(mid_rez.states_blk,resid,25,'.b');
            hold on; gg=ezplot(@(n) 0, [0,200]); set(gg,'Color','k')%,'Width',2)
            ax = gca; ax.YTick = [-80:40:80];
            ylim(80*[-1,1])
            grid on
%             if j==3 || j==4; xlabel('stock, \it{n}'); end
%             if j==1 || j==3; ylabel('residuals'); end
            title(mod,'FontWeight','Normal')
    end
    for jj=4:6; subplot(sph,spw,jj); xlabel('stock, \it{n}'); end
    subplot(sph,spw,1); ylabel('value'); 
    subplot(sph,spw,4); ylabel('residuals'); 
   
    for jj = 1:6
        subplot(sph,spw,jj)
        text(-0.19,1.2,['\bf{(' char('A' + jj - 1) ')}'],'Units', 'Normalized', 'VerticalAlignment', 'Top');          
    end    
    
    figure(11); figname='vf&resid_mid_forms'; %figname='vf_mid_forms';           
%     print([figloc figname],'-depsc','-painters')
%     print([figloc figname],'-dpng','-r0')            

end



