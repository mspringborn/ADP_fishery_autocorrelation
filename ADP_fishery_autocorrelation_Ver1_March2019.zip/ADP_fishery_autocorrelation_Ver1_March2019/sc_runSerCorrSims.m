% sc_runSerCorrSims
% Run and analyze simulations to compare performance (e.g. how important is it to account for autocorrelation (m>0)?  Does policy for m=0 do just about as well when true m>0?

if useSavedSims % sims done just load:
    load([dest_soln '\simRez.mat']); %
    ss = 1;
else
    if dpf; sc_setparllwrks; pctRunOnAll  warning('off','all'); end
    useAct = 1; if useAct; disp('Using actual value function solution instead of interpolation'); end
    % Set simulation params: number of sim chains (nSim), length in periods (TSim), #of final periods to keep (TP, i.e. burn in discarded is first TSim-TP periods).
    if 0        % Medium density
        nSim = 1000; % number of sims.
        TSim = 70;   % number of periods
        TP   = 50;   % final periods used to summarize eq'm behavior
    elseif 1         % High density, for final version
        nSim = 5000; 
        TSim = 70; 
        TP   = 50; 
    elseif 0         % Low density, for testing
        nSim = 100; 
        TSim = 50; 
        TP   = 50; 
    end
    totSim = nSim*TSim;

    %% Set paths for disturbances to shock: 
    numz = 4; % Number of shock variables
    % Shock path disturbance is mean zero (not mean 1) since these are disturbances to an autoregressive process (regressing to 1).
    shock_path_disturb = random(truncate(PDF_norm,-mzv,mzv),nSim,TSim,numz);   % Dim: nSim x TSim x numz.   ezplot(@(x) pdf(PDF_norm,x),[-2,2]);ylim([0,4])
    shock_path_disturb(:,1,:) = NaN;                                           % shock_path for time t=1 not used.

    %% Set scenario for starting state levels 
    % Start stock within a viable range:
    if strcmp(systmodel,'base') || strcmp(systmodel,'rick')   %base bio model
        N1chs = [35,85]; 
    elseif strcmp(systmodel,'critdep') %critical depensation model
        N1chs = [35,85];
    end
    
    % Specify scenario for restrictions on non-stock params starting points.
    ss = 1;     disp(['You are starting state_set (ss) ' num2str(ss)])
    if     ss==1                                    % no restrictions on exogenous state variable starting points.
    elseif ss==2; Kchs  = nK;       Rchs = 1;       % High K, low R for max diff in corr/not corr.
    elseif ss==3; Kchs  = 1;        Rchs = nR;      % Low K, High R for max diff in corr/not corr. 
    elseif ss==4; Kchs  = 2;        Rchs = nR-1;    % almost Low K, almsot High R for max diff in corr/not corr. 
    elseif ss==5; Kchs  = 1;        Rchs = 1;       % both low
    elseif ss==6; Kchs  = nK;       Rchs = nR;      % both high
    elseif ss==7; Kchs  = mPt(2);   Rchs = mPt(3);  % both mid
    elseif ss==8; turnOffZ = [1 2 4]; %Turn off shocks to Z's
    end
    
    %% Set initial starting states and shock level paths
    % Get indices for x_node rows to include in sim
    if ss==1
        nzRows  = find(x_node(:,1)>=N1chs(1) & x_node(:,1)<=N1chs(2));  
    elseif ss>1 && ss<8 
        nzRows  = find(x_node(:,1)>=N1chs(1) & x_node(:,1)<=N1chs(2) & (x_node(:,2)==Kv(Kchs) & x_node(:,3)==Rv(Rchs)));  
    end
    if 0 % Random node draws
        nnzR    = length(nzRows);
        rI      = randperm(nnzR);                           % Random ordering of indices of N>0 rows
        numreps = nSim/nnzR;                                % How many copies of the random ordering will fit in nSim simuluations.
        randInd = repmat(rI(:),[floor(numreps),1]);         % Get the whole copies of the list.
        addRows = nSim-length(randInd);                     % How many rows in the remaining fraction of the list to get to nSim
        randInd = [randInd; rI(1:addRows)'];                % Combine complete and partial list.
        randIAct= nzRows(randInd);                          % Convert from random indices of N>0 rows to row numbers in x_node   
        state_set = x_node(randIAct,:);                     % Convert to actual state levels.    
    elseif 1 %Continuous random draws rather than random nodes.
        state_set(:,1) = N1chs(1) + rand([nSim,1])*(diff(N1chs)); 
        if 1 % Random continuous draws from zmin to zmax;
            state_set(:,2:(1+numz)) = repmat(xMinMax(1,2:end),[nSim,1])+rand(nSim,numz).*repmat(xMinMax(2,2:end)-xMinMax(1,2:end),[nSim,1]);
        elseif 0 % Start at neutral
            state_set(:,2:(1+numz)) = 1; disp('Starting all z at 1.')
        end
    end
    
    % Get shock_path: full simulated paths for temporally correlated shock levels since they're exogenous
    shock_path        = NaN*ones(nSim,TSim,numz);
    shock_path(:,1,:) = state_set(:,2:end);  % set shock level to initial state

    disp(['Shock process based on m = ' num2str(m)])
    for t=2:TSim
        shock_path(:,t,:) = fi_shockNextSerCorr(shock_path(:,t-1,:), shock_path_disturb(:,t,:)); % Function previously named shockNextSerCorr()--may encounter renaming issue with saved results.
        % Impose bounds:  CRITICAL: simple version here must be extended if bounds on shocks differ
        shock_path(:,t,:) = max(xMinMax(1,2),shock_path(:,t,:));  %Impose lower bound
        shock_path(:,t,:) = min(xMinMax(2,2),shock_path(:,t,:));  %Impose lower bound  
    end
    if noprofshock 
        shock_path(:,:,[3 4]) = 1;  % Neutralize shocks for profit terms
    elseif nobiolshock 
        shock_path(:,:,[1 2]) = 1;  % Neutralize shocks for biological terms        
    end
    if ss>=8
        shock_path(:,:,turnOffZ) = 1; 
    end
    
    %check -- Calc correlation between shock levels at t and t+1.  Shock variable 1 only:
    if 0
        getcorr = NaN*ones(1000,1);
        for j=1:1000; getcorr(j)   = corr(shock_path(j,1:5,1)',shock_path(j,2:6,1)'); end
        nanmean(getcorr)
    end


    %% Main loops to run simulations
    %Will use policy already identified at specific points to interpolate. Specify the grid: 
    [N1nd, Knd, Rnd,pnd, cnd] = ndgrid(N1vM,Kv,Rv,pv,cv);   

    % Loop over m=0 and one m>0 scenario
    for j = 1:2
        if     j==1; em = '0'; %zero 
        elseif j==2; em = num2str(100*m); %generic, m 
        end
        eval(['pFun = M' em '.pFun;']); 
        eval(['N1vM = M' em '.N1v;']); %stock vectors might differ
 
        if j==1; cnm = casename0; elseif j==2; cnm = casename95; end 
        if useAct % using actual Value function solution
            eval(['Vfitj = M' em '.Vfit;']); 
        else
            interpMeth = 'spline'; 
        end
        % Pre-allocate output arrays
        [AvSim, profSim, N1Sim, harvSim] = deal(NaN*ones(nSim,TSim));

        %% Loop over sims
        tic
        parfor n_sim_pf = 1:nSim  
%       disp('you have turned parfor off!!!')
%       for n_sim_pf = 1:nSim
                if (n_sim_pf/100 == round(n_sim_pf/100)); disp(['j,n = ' num2str([j n_sim_pf])]); end
                [profSimt,N1Simt,AvSimt,harvSimt] = deal(NaN*ones(1, TSim)); % For all 3 policies at one time.
                N1Simt(1) = state_set(n_sim_pf,1); % Initialize stock vector and allocate space for future simulated values.   
                % Loop over time periods
                for t = 1:TSim
                    % Observe new level of stochastic variable(s)...and 
                    % Calculate (conditional on action a=Av): 
                        % pi_a:         Fishery profit
                        % nextstates_a: Next period's N from this period's N
                     z=squeeze(shock_path(n_sim_pf,t,:)); % Same for all policies
                     N1Preharv = Gf(z(1),z(2),N1Simt(t)); % Post-shock stock. N1Simt(t) is pre-growth/shock starting period state.
                     if ~useAct     % Use interporlation
                        AvSimt(t) = interpn(N1nd,Knd,Rnd,pnd,cnd,pFun,N1Preharv,z(1),z(2),z(3),z(4),interpMeth);%,NaN);
                     elseif useAct  % Get optimal policy from actual value function solution.
                        states = N1Simt(t);  % Just the pre-shock stock
                        [pi_a,nextstates_a]     = f_nextperiod_multshock_sf(z,states,Av,xMinMax,Gf,PI_netprof_mult); %open f_nextperiod_multshock_sf
                        states_ph = [N1Simt(t) z']; % just a placeholder to hold the fitting location--will be dropped
                        if j==1;  predData = M0.txfun(nextstates_a);                       % if m==0
                        else;     predData = [txfun(nextstates_a) repmat(z(:)',[nA,1])];   % m>0
                        end
                        Vn_a = predict(Vfitj,predData); 
                        Vn_a = reshape(Vn_a, size(pi_a));  %Ensure that Vn_a and pi_a vectors are same orientation.
                        % Calc PV of each possible action 
                        V_a  = pi_a + delta*Vn_a;    
%    %viz: 
%     figure(78); %subplot(1,2,1); plot(Av,V_a','.-'); xlabel('action'); ylabel('V_a'); ylim([0,400])
%                 subplot(1,2,1); area(Av,[ delta*Vn_a pi_a]); xlabel('action'); ylabel('V_a'); ylim([0,400]); %weird: negative values show up as positive in area
%                 subplot(1,2,2); plot(Av,delta*Vn_a','.-'); xlabel('action'); ylabel('delta*Vn_a');
%                 states_ph
%     pause(.5)
                            % Identify maximized value and index of optimal action.
                            [~, Policy_Fun_sim]        = max(V_a(:));  % [~, tempi]        = max(V_a(:))    
                            AvSimt(t) = Av(Policy_Fun_sim);
                     end
                     
                     if AvSimt(t)<0 || AvSimt(t)>1 
                         disp(['Escapement out of bounds, N: ' num2str(N1Preharv) ', A:' num2str(AvSimt(t))]); 
                         AvSimt(t) = eps*AvSimt(t)<0 + 1*AvSimt(t)>0; %if <0 then set to eps, o/w is >1 so set to 1.
                     end
                    [profSimt(t),N1Simt(t+1)] = f_nextperiod_multshock_sf(z,N1Simt(t),AvSimt(t),xMinMax,Gf,PI_netprof_mult); %open f_nextperiod_multshock_sf            
                    if profSimt(t)<0  %If negative profit, set esc to 1 (happens at very low stock, interpolation error)
                        AvSimt(t) = 1; 
                        profSimt(t) = 0; 
                        N1Simt(t+1) = N1Preharv;                    
                    end
                    harvSimt(t) = N1Preharv-N1Simt(t+1);
                end
                if 0  % compare outcomes between AvSimt calculated with interpolation (AvSimt) and using actual (saved as "AvSimtAct").
                    figure(99); 
                    subplot(3,1,1); plot(1:80,[AvSimt; AvSimtAct]); legend('interp','calc')
                    subplot(3,1,2); plot(1:80,N1Simt(1:80))
                    subplot(3,1,3); plot(1:80,squeeze(shock_path(n_sim_pf,:,:))); legend('K','R','p','c')
                end
                AvSim(  n_sim_pf,:) = AvSimt; 
                profSim(n_sim_pf,:) = profSimt; 
                N1Sim(  n_sim_pf,:) = N1Simt(1:end-1);      
                harvSim(n_sim_pf,:) = harvSimt; 

        end
        timeFor1M = toc  %200x80--> parfor 68.5 sec, for 111 sec
        disp(['ss =' num2str(ss) ', j = ' num2str(j) ' is complete'])
        eval(['M' em '.ss' num2str(ss) '.AvSim   = AvSim;']); 
        eval(['M' em '.ss' num2str(ss) '.profSim = profSim;']); 
        eval(['M' em '.ss' num2str(ss) '.N1Sim   = N1Sim;']); 
        eval(['M' em '.ss' num2str(ss) '.harvSim = harvSim;']); 
        clear AvSim profSim N1Sim harvSim
    end



    %% simulation comparison scenarios
    if 1      % Correctly apply M>0 policy when M>0
       simScenDx   = ['\rho_{true} = ' num2str(m) ', \rho_A = ' num2str(m)];
       simScenFile = ['Mtrue' num2str(round(100*m)) 'MA' num2str(round(100*m))];
       simScenDx0  = ['\rho_{true} = ' num2str(m) ', \rho_A = 0'];
       %simScenFile = ['Mtrue' num2str(round(100*m)) 'MA' num2str(round(100*m))];
    elseif 0  % Mistakenly apply M>0 policy when M=0
       simScenDx   = ['\rho_{true} = ' num2str(m) ', \rho_A = ' num2str(m)];
       simScenFile = ['Mtrue' num2str(round(100*m)) 'MA' num2str(round(100*m))];
    end


    %% Look at means for all periods for action, profit, stock to see when stabilizes
    % get summary stats for final TP periods (depends on TSim).
    ssInsrt = ['.ss' num2str(ss)]; 

    %for error bars:
    conf = .9;                          % Confidence interval to plot
    negIndx = round(nSim*(1-conf)/2);   % Index of sorted rows for lower bound of conf*100 confidence interval
    posIndx = round(nSim*(1-(1-conf)/2));

    fig=41; fh=figure(fig); clf;  figh=8; figw=10; %figh=3.75; figw=7; %fig width and height
        figSaveTitle = ['serrCorrSimRezM' num2str(100*m) 'Ver' ver 'ss' num2str(ss)];
        set(gcf,'Units','inches','Position',[1,1,figw,figh]); %[left, bottom, width, height]; bottom =1 for laptop, =4.5 for desktop
        set(gcf,'Color','w')
    varCapt = {'Esc','Stock, n (pre-growth)','Profit','Harvest'};
    avgFinalTP = []; % Clear summary array
    for j = [0 m*100]
        eval(['M = M' num2str(j) ssInsrt ';'])
        if     j==0; ttl = ['Simulation means and stds, ' simScenDx0];
        elseif j>0;  ttl = ['Simulation means and stds, ' simScenDx]; 
        end
        if j==0; col = 'r'; else col = 'b'; end
        for i=1:4%[1 3 5]
            subplot(4,1,i)%2,i+1*(j>0)); 
                if     i==1; var2Plt = M.AvSim;
                elseif i==2; var2Plt = M.N1Sim;
                elseif i==3; var2Plt = M.profSim;
                elseif i==4; var2Plt = M.harvSim;
                end
                meanPMstd = [mean(var2Plt)-std(var2Plt); 2*std(var2Plt)]; 
                var2Plt=sort(var2Plt,1); %sort each column (dim =1).
                neg =  mean(var2Plt)-var2Plt(negIndx,:); %distance from mean
                pos = -mean(var2Plt)+var2Plt(posIndx,:); 
                if 0 
                    ap = area(1:TSim,meanPMstd','LineStyle','none'); hold on
                    ap(1).FaceColor = 'none'; ap(2).FaceColor = 'c';
                end
                %plot(1:TSim,mean(var2Plt),[col '.-']); hold on
                errorbar(1:TSim,mean(var2Plt),neg,pos,[col '.-']); hold on 
                grid on; 
                ylabel(varCapt{i});
                if i==1; title(ttl); 
                    legend('\rho = 0','\rho>0')
                end
                CIlow = mean(var2Plt)-neg; CIhigh = mean(var2Plt) + pos; 
                avgFinalTP(i,1+(j>0)*1)     = mean(mean(var2Plt(:,end-TP+1:end)));
                avgFinalTP(i,1+(j>0)*1 + 3) = mean(CIlow(end-TP+1:end)); % Conf int; Average dist below mean 
                avgFinalTP(i,1+(j>0)*1 + 6) = mean(CIhigh(end-TP+1:end)); % Conf int; Average dist below mean 
                if i==1
                    EscTP = var2Plt(:,end-TP+1:end);
                    threshClosed = .999; %threshold of escapement for functional closure
                    shrEsc1TP(1+(j>0)*1) = sum(EscTP(:)>=.999)/numel(EscTP);
                end
        end
        xlabel('time, t')
    end
    avgFinalTP(:,3) = 100*(-avgFinalTP(:,1)+avgFinalTP(:,2))./avgFinalTP(:,1);
    avgFinalTP(:,6) = 100*(-avgFinalTP(:,4)+avgFinalTP(:,5))./avgFinalTP(:,4);
    avgFinalTP(:,9) = 100*(-avgFinalTP(:,7)+avgFinalTP(:,8))./avgFinalTP(:,7);
    avgFinalTPTbl = array2table(avgFinalTP,'VariableNames',{'E_rho_0' ['E_rho_' num2str(m*100)] 'perc_diffE',...
                                                            'CILow_rho_0', ['CILow_rho_' num2str(m*100)] 'perc_diffL',...
                                                            'CIHigh_rho_0', ['CIHigh_rho_' num2str(m*100)] 'perc_diffH'},...
                                           'RowNames',varCapt);
    eval(['M' num2str(100*m) '.ss' num2str(ss) '.avgTbl     = avgFinalTPTbl;'])
    eval(['M' num2str(100*m) '.ss' num2str(ss) '.avgTblParm = [nSim TSim TP];'])
    if saveSims
        save([dest_soln '\simRez.mat'],'M0',['M' num2str(100*m)],'shock_path','threshClosed','useAct','nSim','TP','shrEsc1TP','shock_path'); % Save 
    end
end

if exist('useAct')
    disp(['Using actual value function (instead of interp), 1 if true: ' num2str(useAct)])
end

if ss==1
    if m==.95
        disp(['Averages over final TP periods (nSim, TSim, TP = ' num2str(M95.ss1.avgTblParm) ')'])
        disp(M95.ss1.avgTbl)
        if 1  % ***for copy past to excel (confidence intervals underneath
           tblrez_raw= table2array(M95.ss1.avgTbl);
           tblrez    = round(tblrez_raw*10)/10;  %rounding to 1 decimal
           tblrez(1,:) = round(tblrez_raw(1,:)*100)/100;  %rounding to 2 decimals
           for rowid = 1:4
               disp(num2str(tblrez(rowid,1:3)))
               disp(['(' num2str(tblrez(rowid,4)) ',' num2str(tblrez(rowid,7)) ')   (' num2str(tblrez(rowid,5)) ',' num2str(tblrez(rowid,8)) ')' ])  
           end
           TP = M95.ss1.avgTblParm(3); TSim = M95.ss1.avgTblParm(2); nSim = M95.ss1.avgTblParm(1);
           if ~exist('shrEsc1TP') % this stat wasn't consistently save til later
              TP = M95.ss1.avgTblParm(3); TSim = M95.ss1.avgTblParm(2); nSim = M95.ss1.avgTblParm(1);
              tmp = M95.ss1.AvSim(:,end-TP+1:end); tmp95 = sum(tmp(:)>.999)/numel(tmp);
              tmp = M0.ss1.AvSim(:,end-TP+1:end);  tmp0  = sum(tmp(:)>.999)/numel(tmp);
              percExlTP = 100*[tmp0 tmp95]; % %-form
              disp(num2str(round(10*percExlTP)/10))
           end
           disp(num2str(.1*round(10*[100*[sum(M0.ss1.N1Sim(:,end)==0) sum(M95.ss1.N1Sim(:,end)==0)]/nSim])))
           disp(num2str([nSim TP TSim]))
           disp(casename)
        end
    end
end

if exist('threshClosed') && exist('shrEsc1TP')
    disp(['Share of periods fishery closed (esc share > ' num2str(threshClosed) '; over same range as above): rho_0, rho_' num2str(m*100)])
    disp(shrEsc1TP)
end

if m==.95 && exist('nSim')
    disp(['Percentage of runs extinct by end: rho_0, rho_' num2str(m*100)])
    disp(100*[sum(M0.ss1.N1Sim(:,end)==0) sum(M95.ss1.N1Sim(:,end)==0)]/nSim) 
end

%%  Look at how mean diff changes as more sims are added.
if 0
if exist('TP')
    meanBySimNum95 = cumsum(mean(M95.ss1.profSim(:,end-TP+1:end),2))./([1:nSim])';
    meanBySimNum0 = cumsum(mean(M0.ss1.profSim(:,end-TP+1:end),2))./([1:nSim])';
    figure(6); clf
    subplot(2,1,1); plot([meanBySimNum0 meanBySimNum95] ,'.-'); grid on
    %ylim([31,36]); 
    subplot(2,1,2); plot(100*(-meanBySimNum0 + meanBySimNum95)./meanBySimNum0,'.-')
    %ylim([7,9]); grid on
end
end

%% Look at scatter plot of gains from acknowledging M95 by shock (subplot)
if exist('shock_path')
    meanShk = mean(shock_path(:,end-TP+1:end,:),2); % size(meanShk)
    profDiff = mean(M95.ss1.profSim(:,end-TP+1:end),2) - mean(M0.ss1.profSim(:,end-TP+1:end),2);
    %%
    figure(35); clf
    kp = 5000;
    ind = [2 1 4 3]; % color for subplots 1:4
    sz = 24; %size of marker
    for jj=1:4
        subplot(2,2,jj); 
        scatter(profDiff(1:kp),meanShk(1:kp,1,jj),sz+0*meanShk(1:kp,1,jj),meanShk(1:kp,1,ind(jj)),'.')
        grid on
        xlabel('profDiff: mean prof 95 - 0'); ylabel('z_i'); 
                set(gca,'Color','k')
    end
end

if 1
    %%
    fig=44; figure(fig); clf;  figh=6; figw=8; %figh=3.75; figw=7; %fig width and height
        figtitle = ['hist_M0vM' num2str(m*100) 'nSim' num2str(nSim)]; 
        figtitle = [figtitle '_' systmodel '_' npaltCase];
        set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
        set(gcf,'Color','w')   
    varbls = {'AvSim','N1Sim','harvSim','profSim'};
    varbnm = {'Escapement share','Stock','Harvest','Profit'};
    nbins=30;
    strProp = [' ''Normalization'', ''probability'' '];
    for vi=1:4
        spi = subplot(2,2,vi);
        if 0  %Original: just final periods
            eval(['data1=M0.ss1.' varbls{vi} '(:,end);'])
            eval(['data2=M95.ss1.' varbls{vi} '(:,end);'])
            histvers = 'finalPer';
        elseif 1
            eval(['data1=M0.ss1.' varbls{vi} '(:,end-TP+1:end);']); 
            eval(['data2=M95.ss1.' varbls{vi} '(:,end-TP+1:end);']); 
            if 0
                data1=data1(:);data2=data2(:);
                histvers = 'pooled';
            elseif 1
                data1=mean(data1,2); data2=mean(data2,2);
                histvers = 'temporalMeans';
            end
        end            
        
        
        eval(['h1=histogram(data1,nbins, ' strProp ');']); hold on  % M0.ss1.N1Sim(:,end)
        eval(['h2=histogram(data2,nbins,''FaceAlpha'',.2,''FaceColor'',''y'', ' strProp ');']) 
        if      h1.BinLimits(1)<=h2.BinLimits(1) & h1.BinLimits(2)>=h2.BinLimits(2)
            h1BE=h1.BinEdges;
            cla(spi);%delete(h2);  %clear current axis
            eval(['h1=histogram(data1,nbins, ' strProp ');']); hold on
            eval(['h2=histogram(data2,h1BE,''FaceAlpha'',.75,''FaceColor'',''w'', ' strProp ');']) 
        elseif  h1.BinLimits(1)>=h2.BinLimits(1) & h1.BinLimits(2)<=h2.BinLimits(2)
            h2BE=h2.BinEdges;
            cla(spi);%delete(h1);
            eval(['h1=histogram(data1,h2BE, ' strProp ');']) 
            eval(['h2=histogram(data2,nbins,''FaceAlpha'',.75,''FaceColor'',''w'', ' strProp ');']) 
        else
            BMIN = min([h1.BinLimits h2.BinLimits]);
            BMAX = max([h1.BinLimits h2.BinLimits]);
            cla(spi);%delete(h1); delete(h2);
            eval(['h1=histogram(data1,nbins,''BinLimits'',[BMIN,BMAX], ' strProp ');'])
            eval(['h2=histogram(data2,nbins,''BinLimits'',[BMIN,BMAX],''FaceAlpha'',.75,''FaceColor'',''w'', ' strProp ');'])
        end
        grid on
    %     if vi==1
    %         eval(['h2=histogram(M95.ss1.' varbls{vi} '(:,end),h1.BinEdges,''FaceAlpha'',.2,''FaceColor'',''y'');']) 
    %     else    
    %         eval(['h2=histogram(M95.ss1.' varbls{vi} '(:,end),''FaceAlpha'',.2,''FaceColor'',''y'');']) 
    %     end
    %     h1.BinLimits
    %     h2.BinLimits    
        legend('\rho=0',['\rho=' num2str(m)])
        xlabel([varbnm{vi}])
        if vi==1 || vi==3
            ylabel('probability'); 
        end

    end
    figtitle = [figtitle '_' histvers]
    disp(['Figure for case: ' casename])
    disp(['Figure file name: ' num2str(fig) figtitle])
    if 0
        print([figloc num2str(fig) figtitle],'-dpng','-r0')
        print([figloc num2str(fig) figtitle],'-depsc')%,'-painters')  %with "painters" the eps version didn't carry the overlap well.
        print([figloc num2str(fig) figtitle],'-dpdf')%,'-painters')
    end
end

if 0
    %% Scatter m95 profit as a function of m0 profit (raw data)
    fig=144; figure(fig); clf;  figh=6; figw=8; %figh=3.75; figw=7; %fig width and height
            %figtitle = ['hist_M0vM' num2str(m*100) 'nSim' num2str(nSim)]; 
            %figtitle = [figtitle '_' systmodel '_' npaltCase];
            set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
            set(gcf,'Color','w')   
    tplt = 1:200;
    M0tmp  = M0.ss1.profSim(tplt,end-TP+1:end);
    M95tmp = M95.ss1.profSim(tplt,end-TP+1:end);
    subplot (1,2,1)
        scatter(M0tmp(:),M95tmp(:),'.');
        hold on; 
        ezplot(@(prof) prof, [0,60])
        grid on; xlabel('M0 prof'); ylabel('M95 prof')
    subplot (1,2,2)
        scatter(M95tmp(:),M0tmp(:),'.');
        hold on; 
        ezplot(@(prof) prof, [0,60])
        grid on; ylabel('M0 prof'); xlabel('M95 prof')
end

if 0 
    %%
    fig=145; figure(fig); clf;  figh=6; figw=8; %figh=3.75; figw=7; %fig width and height
            %figtitle = ['hist_M0vM' num2str(m*100) 'nSim' num2str(nSim)]; 
            %figtitle = [figtitle '_' systmodel '_' npaltCase];
            set(gcf,'Units','inches','Position',[1,2,figw,figh]); %[left, bottom, width, height]
            set(gcf,'Color','w')   

    M0tmp  = M0.ss1.profSim(:,end-TP+1:end);   M0tmp = M0tmp(:);
    M95tmp = M95.ss1.profSim(:,end-TP+1:end);  M95tmp = M95tmp(:);
    maxProfM0 = max(M0tmp(:));
    profM0Ub  = ceil(maxProfM0/10)*10;  %round up to nearest 10.
    %profVec = 0:10:profM0Ub; midVec = 5:10:profM0Ub
    profVec = 0:1:profM0Ub; midVec = .5:1:profM0Ub;
    for i=0:1
    for j=1:(length(profVec)-1)
        if i==0 %M0 prof horiz axis
            indBckt = find(M0tmp>=profVec(j) & M0tmp<profVec(j+1)); 
            avgDiff(j) = mean(M95tmp(indBckt)- M0tmp(indBckt)); 
            shrBckt(j) = length(indBckt)/length(M0tmp);
            xlab = 'M0 profit'; ylab = 'M95 prof - M0 prof';
        elseif i==1 %M95 prof horiz axis 
            indBckt = find(M95tmp>=profVec(j) & M95tmp<profVec(j+1)); 
            avgDiff(j) = mean(M0tmp(indBckt)- M95tmp(indBckt)); 
            shrBckt(j) = length(indBckt)/length(M95tmp);
            xlab = 'M95 profit'; ylab = 'M0 prof - M95 prof';
        end   
    end
        subplot(2,2,1+i); bar(midVec,avgDiff); grid on; xlabel(xlab); ylabel(ylab)
        subplot(2,2,3+i); bar(midVec,shrBckt); grid on; xlabel(xlab); ylabel('freq.')
    end
end




return




%% consider differences in profit between policies.
profDiff = M95.ss1.profSim - M0.ss1.profSim; 
mnprfDiff= mean(profDiff,2); 
figure(13); clf
histogram(mnprfDiff)

look = sortrows([mnprfDiff [1:length(mnprfDiff)]'],1);
look(1:10,1) %highest diffs in favor of m0
look(1:10,2) %indices of the same...
%%
%for ii =1:50 %worst perf of m95 versus m0 is at ii =1
for ii =nSim:-1:(nSim-50) %best perf of m95 versus m0 is at ii = numSim
figure(14)
subplot(5,1,1); 
    plot(1:TSim, [M95.ss1.profSim(look(ii,2),:);  M0.ss1.profSim(look(ii,2),:)])
    legend('95','0'); ylabel('prof')
mean([M95.ss1.profSim(look(ii,2),:);  M0.ss1.profSim(look(ii,2),:)]')
subplot(5,1,2); plot(1:TSim, [M95.ss1.harvSim(look(ii,2),:);  M0.ss1.harvSim(look(ii,2),:)])
legend('95','0'); ylabel('harv')
subplot(5,1,3); plot(1:TSim, [M95.ss1.N1Sim(look(ii,2),:);  M0.ss1.N1Sim(look(ii,2),:)])
legend('95','0'); ylabel('N')
subplot(5,1,4); plot(1:TSim, [M95.ss1.AvSim(look(ii,2),:);  M0.ss1.AvSim(look(ii,2),:)])
legend('95','0'); ylabel('Av')
subplot(5,1,5); plot(1:TSim, squeeze(shock_path(look(ii,2),:,:)))
legend('zK','zR','zp','zc'); ylabel('Shock levels')
pause
end


%% Look at individual sims.
figure(27); tvec=1:70;
for ii = 15:5000
    subplot(4,1,1)
    plot(tvec,[M0.ss1.profSim(ii,:); M95.ss1.profSim(ii,:)]); legend('0','95'); ylabel('profit')
        subplot(4,1,2)
    plot(tvec,[M0.ss1.AvSim(ii,:); M95.ss1.AvSim(ii,:)]); legend('0','95'); ylabel('Esc')

        subplot(4,1,3)
    plot(tvec,[M0.ss1.N1Sim(ii,:); M95.ss1.N1Sim(ii,:)]); legend('0','95'); ylabel('stock')
        subplot(4,1,4)
    plot(tvec,[M0.ss1.harvSim(ii,:); M95.ss1.harvSim(ii,:)]); legend('0','95'); ylabel('harv')

    pause
end

