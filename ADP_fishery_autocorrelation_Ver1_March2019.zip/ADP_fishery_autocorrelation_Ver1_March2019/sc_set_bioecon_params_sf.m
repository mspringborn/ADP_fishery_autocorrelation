% sc_set_bioecon_params_sf
% Set bioecon params and functional forms
% Parameterized to match Sethi et al. growth noise example (Exceptions: shock is discretized-truncated-normal versus uniform)

%% Set the economic parameters and functions
p       = 1;           % price per unit harvest, normalized to 1 (Sethi)
delta   = 1/1.05;      % discount factor
% Profit function: price*harvest - (cparm/stock)*harvest
% Harvest = stock*(1-escapement) = N*(1-A)
% Cost: integral of -(cparm/N) from N*A:N is = -cparm*log(1/A) < 0.  Unless the MC is assumed constant.

if doConstMCHarv      % constant marginal cost of harvest 
    cparm      = .25;      
    PI_netprof = @(z,N,A)  (z.*N.*(1-A)).*(p - cparm);  
else   
    cparm = 35;       %
    if strcmp(ver,'Cm10') || strcmp(ver,'Cp10')
        disp(['Altering parameters for sensitivity analysis: ' ver])
        if     strcmp(ver,'Cm10'); cparm = cparm*.9;
        elseif strcmp(ver,'Cp10'); cparm = cparm*1.1; 
        end
    end
    PI_netprof = @(z,N,A)  p.*(z.*N.*(1-A)) - cparm.*log(1./A);  
end
economic_params = {p cparm delta};

if multTCorrShk
    PI_netprof_multTCorrShk = @(zp,zc,N,A)  zp*p.*(N.*(1-A)) - zc*cparm.*log(1./A);  % Shock to N handled separately
    if noprofshock || onlyPshock || onlyCshock % exclude all/some profit shocks.
        PI_netprof_multTCorrShk_temp = PI_netprof_multTCorrShk;
        if noprofshock % exclude all profit shocks.
        PI_netprof_multTCorrShk = @(zp,zc,N,A) PI_netprof_multTCorrShk_temp(1,1,N,A);
        elseif onlyPshock
        PI_netprof_multTCorrShk = @(zp,zc,N,A) PI_netprof_multTCorrShk_temp(zp,1,N,A);  
        elseif onlyCshock
        PI_netprof_multTCorrShk = @(zp,zc,N,A) PI_netprof_multTCorrShk_temp(1,zc,N,A);
    end    
    elseif doConstMCHarv  % constant marginal cost of harvest
        PI_netprof_multTCorrShk = @(zp,zc,N,A)  (N.*(1-A)) .* (zp*p - zc*cparm);  % PI_netprof_ConstMCHarv
    end
end

if 0  %plot payoffs (revenues, costs, ratio, profits).
    figure(77);
    %escp=71.1; %cparm =5;    %escp=53; %cparm =10;    %escp=61.25; %cparm =25;  %escp=62.9; %cparm =30;
    escp=65; %cparm =35;
    subplot(2,2,1); ezplot(@(x)  PI_netprof(1,x,escp./x),  [escp,200]); ylabel('profit'); title(['cparm = ' num2str(cparm)])
    subplot(2,2,4); ezplot(@(x)  cparm.*log(1./(escp./x)), [escp,200]); ylabel('cost')
    subplot(2,2,2); ezplot(@(x)  p.*(x.*(1-(escp./x))),    [escp,200]); ylabel('rev.')
    subplot(2,2,3); ezplot(@(x)  (cparm.*log(1./(escp./x))) ./  (p.*(x.*(1-(escp./x)))),    [escp,200]); ylabel('cost/rev')
end

%% Set the biological parameters and dynamics
%Logistic growth model:
R            = 1;                       % Intrinsic growth rate
K            = 100;                     % Carrying capacity
if strcmp(ver,'Km10') || strcmp(ver,'Kp10')
    disp(['Altering parameters for sensitivity analysis: ' ver])
    if     strcmp(ver,'Km10'); K = K*.9;
    elseif strcmp(ver,'Kp10'); K = K*1.1; 
    end
end


G_logist_std = @(s) s.*(1+R*(1-s/K));   % Pop dynamics with logistic growth (as a function of escapement)
K0           = .25*K;                   % Conrad sets K=1, K0=.25
G_logist_cdep = @(s) max(0, s + s.*R.*(1-s/K).*(s/K0-1)) ;   % Logistic growth with crit dep. (Conrad 2010, p. 77, eq'n 3.1d)
if 0 %visualize
    figure(117); funG = G_logist_std;  ezplot(@(s) funG(s), [0,200]); hold on; grid on
                 funG = G_logist_cdep; ezplot(@(s) funG(s), [0,200]); 
                 plot([0,120],[0,120],'-'); title('N_{t+1}(N_t)'); ylabel('N_{t+1}'); xlabel('N_t')
    figure(118); funG = G_logist_std;  ezplot(@(s) funG(s)-s, [0,100]); grid on; ylim([0,25])
end

N_max       = 200; %K*1.75;%1.5;    % maximum value of the assessed stock
Nminvia     = 0;                    % minimum viable population

% Modification for stability: for stock levels way above carrying cap, after growth stock can go to zero. These levels aren't important
% because stock won't reside in this neighborhood.  But they can cause difficulties for the value function.  Here we just modify the 
% growth at such high N to fall all the way to 5% of carrying capacity instead of zero. Won't affect results but eases modeling of value function.
if 1
    Ncrash = 5; % If N>zK*K and is going to crash, crash only down to Ncrash, rather than zero. 
    %disp('Implementing Ncrash limit in biological dynamics')
    G_logist_std_multshock_base = @(zK,zR,s) min(N_max,max(0, s.*(1 + zR.*R.*(1-s./(zK*K)))  ) ); % logistic with shock for car cap (zK) and growth rate (zR) 
    % Logical split in function handles need to impost Ncrash at high starting N but not at low N
    G_logist_std_multshock = @(zK,zR,s) (s<=zK*K) .* G_logist_std_multshock_base(zK,zR,s) + ...
                                        (s>zK*K)  .* max(Ncrash,G_logist_std_multshock_base(zK,zR,s));
    %same for crit dep.       
    Ncrash_cdep = 30;%35;
    G_logist_cdep_multshock_base = @(zK,zK0,s) min(N_max,max(0, s + s.*R.*(1-s./(K*zK)).*(s./(K0*zK0)-1)) );   
    G_logist_cdep_multshock      = @(zK,zK0,s) (s<=zK*K) .* G_logist_cdep_multshock_base(zK,zK0,s) + ... 
                                                (s>zK*K)  .* max(Ncrash_cdep,G_logist_cdep_multshock_base(zK,zK0,s));
end

if 0 %visualize
    figure(119); funG = G_logist_std_multshock;  ezplot(@(s) funG(1,.5,s), [0,200]); hold on; grid on
                              plot([0,120],[0,120],'-'); title('N_{t+1}(N_t)'); ylabel('N_{t+1}'); xlabel('N_t')
end

% Handle exclusions of certain shocks for multTCorrShk model:
if multTCorrShk
    if nobiolshock || onlyKshock || onlyRshock % exclude all/some biological shocks.
        G_logist_std_multshock_withShocks  = G_logist_std_multshock; 
        G_logist_cdep_multshock_withShocks = G_logist_cdep_multshock; 
        if nobiolshock 
            G_logist_std_multshock  = @(zK,zR,s)  G_logist_std_multshock_withShocks(1,1,s); 
            G_logist_cdep_multshock = @(zK,zK0,s) G_logist_cdep_multshock_withShocks(1,1,s); 
        elseif onlyKshock % only K shocks.
            G_logist_std_multshock  = @(zK,zR,s)  G_logist_std_multshock_withShocks(zK,1,s); 
            G_logist_cdep_multshock = @(zK,zK0,s) G_logist_cdep_multshock_withShocks(zK,1,s); 
        elseif onlyRshock % only R or K0 shocks.
            G_logist_std_multshock  = @(zK,zR,s)  G_logist_std_multshock_withShocks(1,zR,s); 
            G_logist_cdep_multshock = @(zK,zK0,s) G_logist_cdep_multshock_withShocks(1,zK0,s); 
        end
    end
end

% Ricker recruitment function.
a = 25;         
b = 3;          
G_Rick_std = @(s) s*.85 + (a*s)./(b+s);   % Pop dynamics with Ricker (as a function of escapement)
G_Rick_std_multshock = @(zK,zR,s) s*.85 + (a*zR.*s)./(b*zK+s);

% For serial correlation shock model, specify what the shock level will be in next period, z_{t+1}, given z_t 
if multTCorrShk
    % shock level is mean 1 (multiplicative)
    fi_shockNextSerCorr  = @(shockCurr,shockDist) m*shockCurr + (1-m)*1 + shockDist;  % z_{t+1} = m*z_t + (1-m)*1 + eps_t, where eps_t is the disturbane to the shock level.  
end

%% Specify growth function (Gf) choice and max/min values of stock.
if ~multTCorrShk
    if     strcmp(systmodel,'base')   ; Gf = G_logist_std;
    elseif strcmp(systmodel,'critdep'); Gf = G_logist_cdep;
    elseif strcmp(systmodel,'rick');    Gf = G_Rick_std;   
    end
elseif multTCorrShk
    if     strcmp(systmodel,'base')   ; Gf = G_logist_std_multshock; 
    elseif strcmp(systmodel,'critdep'); Gf = G_logist_cdep_multshock;
    elseif strcmp(systmodel,'rick');    Gf = G_Rick_std_multshock;
    end                
end



if 0  % visualize
    figure(2121); clf;
    %   xub=K; ezplot(@(S) G_logist_std(S)-S,[0,xub]); hold on; ezplot(@(S) G_logist_cdep(S)-S,[0,xub]); yl=ylim; ylim([-5 yl(2)]); legend('growth std','growth cdep'); grid on; title('');
    xub=K*2; ezplot(@(S) G_logist_std(S),[0,xub]); hold on; ezplot(@(S) G_logist_cdep(S),[0,xub]); yl=ylim; ylim([0 120]); legend('N'' std','N'' cdep'); grid on; title('');
end