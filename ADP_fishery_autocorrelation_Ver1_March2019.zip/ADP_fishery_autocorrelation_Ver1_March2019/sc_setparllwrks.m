% sc_setparllwrks
% If a parallel pool doesn't already exist, set the number of parallel workers depending on computer:

if doparfor
    poolobj = gcp('nocreate'); % If no pool, do not create new one.
    if isempty(poolobj)
        [~, parcompname] = system('hostname');
        switch strtrim(parcompname)
            case 'ESP-MSN-4812' %'springborn-PC'  %Mike's desktop
                wrkrs=8; % 
%             case 'SpringbornS7'   %Mike's laptop
%                 wrkrs=2;
            case 'ESP-MSN-0857'   %Mike's rack machine
                wrkrs=12;    %
            case {'ESP-MSN-8822','AmandaFaigsiMac'}
                wrkrs=4;
        end
        delete(gcp('nocreate'));  %delete any existing parallel pool.
       poolobj = parpool('local',wrkrs); % create a parallel pool -- to use parfor (parallel loop)
    end
end

